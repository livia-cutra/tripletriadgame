package controller;

/**
 * Interface for observing player actions and notifying them about their turn state. Implementations
 * of this interface are responsible for reacting to commands from the controller, such as starting
 * or ending a turn. This interface also allows retrieving a player-specific property, such as their
 * color or identifier.
 *
 * @param <T> the type representing a player's unique property (e.g., color, ID)
 */
public interface PlayerObserver<T> {

  /**
   * Notifies the player to start their turn. Implementations should enable any necessary
   * interactions or logic required for the player to make a move.
   */
  void startTurn();

  /**
   * Notifies the player to end their turn. Implementations should disable interactions and prepare
   * for the next player's turn.
   */
  void endTurn();

  /**
   * Retrieves a unique property of the player, such as their color or identifier.
   *
   * @return the player's unique property of type {@code T}
   */
  T getColor();
}
