package controller;

import model.Color;
import view.GameView;

/**
 * Represents a human player in a turn-based board game.
 * The human player interacts with the game through a graphical user interface (GUI).
 */
public class HumanPlayer implements PlayerObserver<Color> {
  private final GameView view;
  private final Color color;

  /**
   * Constructs a HumanPlayer with the specified view and player color.
   *
   * @param view  the game view associated with this human player
   * @param color the color representing this player's team
   */
  public HumanPlayer(GameView view, Color color) {
    this.view = view;

    this.color = color;
  }

  /**
   * Starts the player's turn by enabling interactions in the game view.
   * This allows the player to make their move.
   */
  @Override
  public void startTurn() {
    view.enableInteractions(true);
  }

  /**
   * Ends the player's turn by disabling interactions in the game view.
   * This prevents the player from making moves while it is not their turn.
   */
  @Override
  public void endTurn() {
    view.enableInteractions(false);
  }

  /**
   * Retrieves the color associated with this human player.
   *
   * @return the color representing the player's team
   */
  public Color getColor() {
    return color;
  }
}
