package controller;

import java.util.List;

import model.MutableTTB;

/**
 * ControllerTTB manages the flow of the game, controlling both the player and AI turns.
 * It interacts with the game model and view, initiating the game, processing player moves, and
 * invoking AI moves.
 */
public class ControllerTTB implements ControllerTTBInterface {
  private final MutableTTB model;
  private final ModelListener redController;
  private final ModelListener blueController;

  /**
   * ControllerTTB constructor starts off the controller and adds listeners.
   */
  public ControllerTTB(MutableTTB model, ModelListener redController, ModelListener
          blueController) {
    this.model = model;
    this.redController = redController;
    this.blueController = blueController;

    model.addModelListener(redController);
    model.addModelListener(blueController);
  }

  /**
   * Starts the game with the specified parameters, initializing the game board, player hands, and
   * views.
   *
   * @param rows     the number of rows for the game board
   * @param cols     the number of columns for the game board
   * @param readGrid the initial configuration of the board
   * @param cards    a list of card names to be used in the game
   * @param shuffle  whether to shuffle the deck of cards
   */
  public void startGame(int rows, int cols, char[][] readGrid, List<String> cards,
                        boolean shuffle) {
    model.startGame(rows, cols, readGrid, cards, shuffle);
    redController.getView().updateGameState(
            model.getPlayerRed().getHand(), model.getPlayerBlue().getHand(), model.getBoard());
    if (blueController.getView() != null) {
      blueController.getView().updateGameState(
              model.getPlayerRed().getHand(), model.getPlayerBlue().getHand(), model.getBoard());
    }
    model.notifyPlayerTurn(model.getPlayerString());


  }
}

