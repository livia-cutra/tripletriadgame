package controller;

import java.util.List;

import model.Color;
import model.MutableTTB;
import view.GameView;

/**
 * The AIListener class is responsible for managing the interaction between an AI player,
 * the game model, and the view. It listens to model events and coordinates the AI's actions
 * during its turn.
 */
public class AIListener implements ModelListener {
  PlayerObserver<Color> player;
  MutableTTB model;
  GameView view;
  AIPlayer ai;

  /**
   * Constructs an AIListener.
   *
   * @param player the AI player observer.
   * @param model the game model.
   * @param view the game view associated with the AI player.
   * @param strategy the strategy the AI player should use.
   */
  public AIListener(PlayerObserver<Color> player, MutableTTB model, GameView view,
                    String strategy) {
    this.player = player;
    this.model = model;
    this.view = view;
    view.updateGameState(model.getPlayerRed().getHand(), model.getPlayerBlue().getHand(),
            model.getBoard());
    this.ai = new AIPlayer(model, player.getColor(), strategy);
  }

  /**
   * Handles the event when it's a player's turn. If the AI player is the current player,
   * it determines and executes its move, updates the game state in the view, and signals
   * the end of the turn.
   *
   * @param playerName the name of the player whose turn it is.
   */
  @Override
  public void onPlayerTurn(String playerName) {
    if (!model.isGameOver()) {
      if (player.getColor().equals(model.getCurrPlayer().getColor())) {
        player.startTurn();
        List<Integer> arr = ai.determineMove();
        model.placeCardTTB(arr.get(0), arr.get(1), arr.get(2));
        view.updateGameState(model.getPlayerRed().getHand(), model.getPlayerBlue().getHand(),
                model.getBoard());
        model.nextTurn();
      }
      player.endTurn();
    }
  }

  /**
   * Handles the event when the game is over. Displays a message in the view indicating
   * the winner of the game.
   *
   * @param winnerName the name of the winning player.
   */
  @Override
  public void onGameOver(String winnerName) {
    view.showMessage("Game Over! Winner: " + winnerName + " " + "Score:" +
            model.getPlayerScore(model.getCurrPlayer()));
  }

  /**
   * Returns the view associated with the AIListener.
   *
   * @return the GameFrame view.
   */
  @Override
  public GameView getView() {
    return view;
  }
}
