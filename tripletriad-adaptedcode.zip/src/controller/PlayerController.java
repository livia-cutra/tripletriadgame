package controller;

import model.Color;
import model.MutableTTB;
import view.Features;
import view.GameView;

/**
 * Represents a controller for a player in the game.
 * This class manages interactions between the PlayerObserver, MutableTTB model,
 * and GameFrame view. It listens to events from the model and view,
 * updates the game state, and facilitates the player's actions during their turn.
 */
public class PlayerController implements ModelListener {
  private final PlayerObserver<Color> player;
  private final MutableTTB model;
  private final view.GameView view;

  /**
   * Constructs a PlayerController with the specified player, model, and view.
   * The controller sets up the view's features and registers itself to handle player actions
   * and game events.
   *
   * @param player the player observer associated with this controller
   * @param model  the mutable game model
   * @param view   the game frame for this player's perspective
   */
  public PlayerController(PlayerObserver<Color> player, MutableTTB model, GameView view) {
    this.player = player;
    this.model = model;
    this.view = view;
    //initialize teh view with teh current game state
    view.updateGameState(model.getPlayerRed().getHand(), model.getPlayerBlue().getHand(),
            model.getBoard());

    // register the view's event handlers
    view.setFeatures(new Features() {
      @Override
      public void selectCard(int cardIndex, String ownerName) {
        handleCardSelection(cardIndex);
      }

      @Override
      public void selectCell(int row, int col) {
        handleCellSelection(row, col);
      }
    });
  }

  /**
   * Notifies the controller when it is the player's turn. The controller updates the view,
   * enabling interactions for the active player and displaying the current turn status.
   *
   * @param playerName the name of the player whose turn it is
   */
  @Override
  public void onPlayerTurn(String playerName) {
    if (player.getColor().equals(model.getCurrPlayer().getColor())) {
      player.startTurn();
      view.updateGameState(model.getPlayerRed().getHand(), model.getPlayerBlue().getHand(),
              model.getBoard());
      view.showMessage(playerName + "'s turn");
    } else {
      player.endTurn();
      view.updateGameState(model.getPlayerRed().getHand(), model.getPlayerBlue().getHand(),
              model.getBoard());
      view.showMessage("Waiting for Opponent...");

    }
  }

  /**
   * Notifies the controller when the game is over. Displays the winner's name in the view.
   *
   * @param winnerName the name of the player who won the game
   */
  @Override
  public void onGameOver(String winnerName) {
    view.showMessage("Game Over! Winner: " + winnerName + " " + "Score: " +
            model.getPlayerScore(model.getCurrPlayer()));
  }

  /**
   * Retrieves the game view associated with this controller.
   *
   * @return the GameFrame instance for this controller
   */
  @Override
  public GameView getView() {
    return view;
  }

  /**
   * Handles the selection of a card by the player. Throws an error if a player selects a card from
   * the opposing player's hand.
   *
   * @param cardIndex the index of the selected card
   */
  private void handleCardSelection(int cardIndex) {
    //remains empty
  }

  /**
   * Handles the selection of a cell on the board by the player. Attempts to place the selected
   * card on the specified cell. Updates the game state in the view and advances the game turn.
   * If the action is invalid, an error message is displayed.
   *
   * @param row the row index of the selected cell
   * @param col the column index of the selected cell
   */
  private void handleCellSelection(int row, int col) {
    try {
      model.placeCardTTB(row, col, view.getSelectedCardIndex(model.getCurrPlayer()));
      view.updateBoard(model.getBoard());
      if (model.isGameOver()) {
        view.showMessage("Game Over!");
      } else {
        model.nextTurn();
      }
    } catch (IllegalArgumentException e) {
      view.showError(e.getMessage());
    }
  }

}


