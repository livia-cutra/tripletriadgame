package controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import model.Card;
import model.Cell;
import model.Color;
import model.MutableTTB;
import model.Player;
import model.ReadOnlyTTB;
import model.TTB;

/**
 * Represents an AI player for a turn-based board game. This AI player makes
 * strategic moves to maximize card placement on the board by prioritizing
 * high-value edges or a greedy strategy to flip the most cards.
 */
public class AIPlayer implements PlayerObserver {

  //copy of model to be mutated
  private ReadOnlyTTB model;
  private MutableTTB modelClone;
  private List<Card> currHand;
  private Color color;
  private String strategy;


  /**
   * Constructs an AIPlayer with the specified game model.
   *
   * @param model the read-only game model providing information about the current game state
   * @param color the color of the AI player.
   * @param strategy the strategy the AI player should use.
   */
  public AIPlayer(ReadOnlyTTB model, Color color, String strategy) {
    this.model = model;
    this.color = color;
    this.strategy = strategy;
  }

  /**
   * Determines the AI's move based on the selected strategy.
   *
   * @return a list containing [row, col, hand index] for the move
   */
  public List<Integer> determineMove() {
    this.modelClone = cloneModel(model);
    this.currHand = modelClone.getCurrPlayer().getHand();

    switch (strategy.toLowerCase()) {
      case "strategy_1":
        return minimaxStrategy();
      case "strategy_2":
        return greedy();
      case "strategy_3":
        return maximizeValueOfEdge();
      default:
        throw new IllegalArgumentException("Unknown strategy: " + strategy);
    }
  }

  /**
   * This is the greedy strategy.
   * This strategy determines which card to place that will flip the most cards on the board.
   * This will always be used on the last possible turn
   *
   * @return an array[row, col, hand index, number of owned cards]
   */
  private List<Integer> greedy() {
    int max = -1;
    int maxRow = -1;
    int maxCol = -1;
    int maxHandIndex = -1;
    List<Integer> result = new ArrayList<>();
    for (int i = 0; i < model.getRows(); i++) {
      for (int j = 0; j < model.getCols(); j++) {
        Cell c = model.getBoard()[i][j];
        if (!c.isHole() && !c.isCard()) {
          for (int k = 0; k < currHand.size(); k++) {
            TTB<Cell> testModel = cloneModel(model);
            testModel.placeCardTTB(i, j, k);
            int owned = determineOwned(testModel);
            if (owned > max) {
              max = owned;
              maxRow = i;
              maxCol = j;
              maxHandIndex = k;
            }
          }
        }
      }
    }
    result.add(maxRow);
    result.add(maxCol);
    result.add(maxHandIndex);
    result.add(max);
    return result;
  }

  /**
   * Tries to maximize a card in hand's respective to the edge.
   * It first prioritzes corners.
   * It then prioritizes edges.
   * It starts by trying to eliminate low numbers from the edges.
   *
   * @return A List of [row, col, hand index]
   */
  private List<Integer> maximizeValueOfEdge() {
    Cell[][] b = modelClone.getBoard();

    int valueTopRight = Integer.MAX_VALUE;
    int indexTopRight = -1;
    int valueBottomRight = Integer.MAX_VALUE;
    int indexBottomRight = -1;
    int valueTopLeft = Integer.MAX_VALUE;
    int indexTopLeft = -1;
    int valueBottomLeft = Integer.MAX_VALUE;
    int indexBottomLeft = -1;

    for (int i = 0; i < currHand.size(); i++) {
      if (valueTopRight > currHand.get(i).getNorthVal() + currHand.get(i).getEastVal()) {
        valueTopRight = currHand.get(i).getNorthVal() + currHand.get(i).getEastVal();
        indexTopRight = i;
      }
      if (valueBottomRight > currHand.get(i).getSouthVal() + currHand.get(i).getEastVal()) {
        valueBottomRight = currHand.get(i).getSouthVal() + currHand.get(i).getEastVal();
        indexBottomRight = i;
      }
      if (valueTopLeft > currHand.get(i).getNorthVal() + currHand.get(i).getWestVal()) {
        valueTopLeft = currHand.get(i).getNorthVal() + currHand.get(i).getWestVal();
        indexTopLeft = i;
      }
      if (valueBottomLeft > currHand.get(i).getSouthVal() + currHand.get(i).getWestVal()) {
        valueBottomLeft = currHand.get(i).getSouthVal() + currHand.get(i).getWestVal();
        indexBottomLeft = i;
      }
    }

    if (!b[0][0].isCard() && !b[0][0].isHole()) {
      return new ArrayList<>(Arrays.asList(0, 0, indexTopLeft));
    } else if (!b[0][model.getCols() - 1].isCard()
            &&
            !b[0][model.getCols() - 1].isHole()) {
      return new ArrayList<>(Arrays.asList(0, model.getCols() - 1, indexTopRight));
    } else if (!b[model.getRows() - 1][0].isCard()
            &&
            !b[model.getRows() - 1][0].isHole()) {
      return new ArrayList<>(Arrays.asList(model.getRows() - 1, 0, indexBottomRight));
    } else if (!b[model.getRows() - 1][model.getCols() - 1].isCard()
            &&
            !b[model.getRows() - 1][model.getCols() - 1].isHole()) {
      return new ArrayList<>(Arrays.asList(model.getRows() - 1, model.getCols() - 1,
              indexBottomRight));
    }
    return null;
  }

  /**
   * Creates a clone of the given game model to allow the AI to simulate moves
   * without altering the original game state.
   *
   * @param model the read-only model to clone
   * @return a new instance of TTB of Cell that replicates the board and player states
   */
  private TTB<Cell> cloneModel(ReadOnlyTTB model) {
    return new TTB<Cell>(model.getBoard(),
            model.getPlayerRed().getHand(), model.getPlayerBlue().getHand());
  }

  /**
   * Determines the number of cells on the board owned by the current player in the model.
   * A cell is considered owned if the color of the cell's owner matches the current player's color.
   *
   * @param model the game model containing the current player's ownership data
   * @return the count of cells owned by the current player
   */
  private int determineOwned(TTB<Cell> model) {
    int count = 0;
    for (int i = 0; i < model.getRows(); i++) {
      for (int j = 0; j < model.getCols(); j++) {
        Cell c = model.getBoard()[i][j];
        try {
          if (c.getOwnerColor().equals(model.getCurrPlayer().getColor())) {
            count++;
          }
        } catch (IllegalStateException ignored) {
        }
      }
    }
    return count;
  }


  /**
   * EXTRA CREDIT Strategy 3: Minimizes the risk of the AI's card being flipped by the opponent.
   * This strategy evaluates potential card placements and selects the position that carries the
   * lowest risk of being flipped by an opponent's card.
   *
   * @return list containing rowindex, colindex, and handindex of card placement w lowest flip risk.
   */
  private List<Integer> minimizeFlipRisk() {
    try {
      int minFlipRisk = Integer.MAX_VALUE;
      int chosenRow = -1;
      int chosenCol = -1;
      int chosenHandIndex = -1;

      for (int i = 0; i < model.getRows(); i++) {
        for (int j = 0; j < model.getCols(); j++) {
          Cell cell = model.getBoard()[i][j];
          if (!cell.isHole() && !cell.isCard()) {
            for (int k = 0; k < currHand.size(); k++) {
              TTB<Cell> testModel = cloneModel(model);
              testModel.placeCardTTB(i, j, k);
              int flipRisk = calculateFlipRisk(testModel, i, j);

              if (flipRisk < minFlipRisk) {
                minFlipRisk = flipRisk;
                chosenRow = i;
                chosenCol = j;
                chosenHandIndex = k;
              }
            }
          }
        }
      }
      return List.of(chosenRow, chosenCol, chosenHandIndex);
    } catch (Exception e) {
      return null;
    }
  }

  /**
   * Calculates the flip risk at a specific board position. It simulates placing a card at the
   * given position and determines how many of the opponent’s cards could potentially flip the AI's
   * card.
   *
   * @param testModel the game model used to simulate placing a card
   * @param row       the row index where the AI places its card
   * @param col       the column index where the AI places its card
   * @return the num of potential flips by opponent if AI places a card at the specified position
   */
  private int calculateFlipRisk(TTB<Cell> testModel, int row, int col) {
    int riskCount = 0;
    List<Card> opponentHand = testModel.getPlayerRed().getHand();

    for (Card card : opponentHand) {
      if (canFlip(testModel, row, col, card, testModel.getPlayerBlue())) {
        riskCount++;
      }
    }
    return riskCount;
  }

  /**
   * Determines if placing a card at a given position can flip an opponent's card.
   *
   * @param row  the row index where the card will be placed
   * @param col  the column index where the card will be placed
   * @param card the card the AI is considering placing
   * @return true if the card can flip at least one opponent's card; false otherwise
   */
  private boolean canFlip(TTB<Cell> testModel, int row, int col, Card card, Player currentPlayer) {
    Cell[][] board = modelClone.getBoard();
    //check north
    if (row > 0 && board[row - 1][col].hasOpponentCard(currentPlayer)) {
      Card opponentCard = board[row - 1][col].getCard();
      if (card.getNorthVal() > opponentCard.getSouthVal()) {
        return true;
      }
    }
    //check south
    if (row < board.length - 1 && board[row + 1][col].hasOpponentCard(currentPlayer)) {
      Card opponentCard = board[row + 1][col].getCard();
      if (card.getSouthVal() > opponentCard.getNorthVal()) {
        return true;
      }
    }
    //check east
    if (col < board[row].length - 1 && board[row][col + 1].hasOpponentCard(currentPlayer)) {
      Card opponentCard = board[row][col + 1].getCard();
      if (card.getEastVal() > opponentCard.getWestVal()) {
        return true;
      }
    }
    //check west
    if (col > 0 && board[row][col - 1].hasOpponentCard(currentPlayer)) {
      Card opponentCard = board[row][col - 1].getCard();
      if (card.getWestVal() > opponentCard.getEastVal()) {
        return true;
      }
    }
    return false; //no adjacent flips are possible
  }


  /**
   * EXTRA CREDIT Strategy 4: Implements a minimax strategy, selecting a position that leaves
   * the opponent with the worst possible options by minimizing the potential flips for the
   * opponent. This strategy assesses placements that restrict the opponent's advantageous moves.
   *
   * @return list containing chosen placement that minimizes the opponent's possible flips.
   */
  private List<Integer> minimaxStrategy() {
    int minOpponentFlip = Integer.MAX_VALUE;
    int bestRow = -1;
    int bestCol = -1;
    int bestHandIndex = -1;

    for (int i = 0; i < model.getRows(); i++) {
      for (int j = 0; j < model.getCols(); j++) {
        Cell cell = model.getBoard()[i][j];
        if (!cell.isHole() && !cell.isCard()) {
          for (int k = 0; k < currHand.size(); k++) {
            TTB<Cell> testModel = cloneModel(model);
            testModel.placeCardTTB(i, j, k);
            int opponentBestFlip = calculateOpponentBestFlip(testModel);

            if (opponentBestFlip < minOpponentFlip) {
              minOpponentFlip = opponentBestFlip;
              bestRow = i;
              bestCol = j;
              bestHandIndex = k;
            }
          }
        }
      }
    }
    return List.of(bestRow, bestCol, bestHandIndex);
  }

  /**
   * Calculates the maximum possible flips an opponent can make based on a simulated game state.
   * This evaluates each potential opponent move and returns the highest number of flips possible,
   * providing insight into the opponent’s best option.
   *
   * @param testModel the game model used to simulate the opponent’s move
   * @return the maximum number of flips the opponent can achieve with a single move
   */
  private int calculateOpponentBestFlip(TTB<Cell> testModel) {
    int maxFlips = 0;
    List<Card> opponentHand = testModel.getPlayerRed().getHand();

    for (int i = 0; i < model.getRows(); i++) {
      for (int j = 0; j < model.getCols(); j++) {
        Cell cell = model.getBoard()[i][j];
        if (!cell.isHole() && !cell.isCard()) {
          for (Card card : opponentHand) {
            TTB<Cell> opponentModel = cloneModel(testModel);
            opponentModel.nextTurn();
            opponentModel.placeCardTTB(i, j, opponentHand.indexOf(card));
            int flippedCards = determineOwned(opponentModel);
            maxFlips = Math.max(maxFlips, flippedCards);
          }
        }
      }
    }
    return maxFlips;
  }


  /**
   * Starts the AI's turn by determining its move and executing it in a new thread.
   */
  @Override
  public void startTurn() {
    new Thread(this::makeMove).start();
  }

  /**
   * Executes the AI's move by determining its strategy and placing a card.
   */
  private void makeMove() {
    List<Integer> move = determineMove();
    modelClone.placeCardTTB(move.get(0), move.get(1), move.get(2));
    modelClone.nextTurn();
  }

  /**
   * Ends the AI's turn. This is a no-op for the AI.
   */
  @Override
  public void endTurn() {
    // no-op for AI
  }

  /**
   * Retrieves the color of the AI player.
   *
   * @return the color representing the AI player's team
   */
  public Color getColor() {
    return color;
  }
}







