package view;

import java.util.List;

import model.Card;
import model.Cell;
import model.Color;
import model.Player;
import model.ReadOnlyTTB;

/**
 * Represents the view component of the Triple Trios game.
 * <p>
 * This class is responsible for rendering the current state of the game, including the player,
 * board, and hand of cards, using an appendable output.
 * </p>
 *
 * @param <C> the type of Card used in the game
 */
public class TTBView<C extends Card> {

  private ReadOnlyTTB model;

  /**
   * Constructs a TripleTriosTextView with the specified model and appendable.
   *
   * @param model the TripleTriosModel that provides the game state
   * @param ap    the Appendable
   */
  public TTBView(ReadOnlyTTB model, Appendable ap) {
    this.model = model;
  }

  /**
   * Returns a string representation of the current game state, including
   * the current player, the game board, and the player's hand.
   *
   * @return a string displaying the grid, hand, and possibly the winner if the game is over.
   */
  @Override
  public String toString() {
    String playerString = "Player: ";
    String boardString = "";
    String handString = "Hand:\n";
    if (model.getCurrPlayer().equals(model.getPlayerRed())) {
      playerString += "Red\n";
    } else {
      playerString += "Blue\n";
    }
    Cell[][] board = model.getBoard();
    for (int i = 0; i < board.length; i++) {
      for (int j = 0; j < board[i].length; j++) {
        boardString += board[i][j].toString();
      }
      boardString += "\n";
    }
    List<Card> cardList = model.getCurrPlayer().getHand();
    for (int i = 0; i < cardList.size(); i++) {
      handString += cardList.get(i).getName() + " ";
      handString += valueToString(cardList.get(i).getNorthVal()) + " ";
      handString += valueToString(cardList.get(i).getSouthVal()) + " ";
      handString += valueToString(cardList.get(i).getEastVal()) + " ";
      handString += valueToString(cardList.get(i).getWestVal());
      handString += "\n";
    }

    if (model.isGameOver()) {
      String winnerString = "Winner: ";
      Player winner = model.getWinner();
      if (winner == null) {
        winnerString += "None, it was a draw\n";
      }
      if (winner.getColor().equals(Color.RED)) {
        winnerString += "Red\n";
      }
      if (winner.getColor().equals(Color.BLUE)) {
        winnerString += "Blue\n";
      }
      return playerString + boardString + handString + winnerString;
    }
    return playerString + boardString + handString;
  }

  /**
   * Converts a card value to a string representation, showing "A" for the value 10.
   *
   * @param value the card value
   * @return "A" if the value is 10, otherwise the string representation of the value
   */
  private String valueToString(int value) {
    return value == 10 ? "A" : Integer.toString(value);
  }
}
