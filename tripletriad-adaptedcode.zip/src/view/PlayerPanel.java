package view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

import model.Card;

/**
 * The PlayerPanel class represents the panel displaying the cards of a player in the game.
 * It allows interaction by detecting mouse clicks to select a card, and it customizes the
 * graphical rendering of the cards. The selected card is highlighted with a border.
 */
class PlayerPanel extends JPanel {
  //list of cards in the player's hand.
  private List<Card> playerHand;
  //the color associated with the player.
  private Color playerColor;
  //the name or identifier of the player.
  private String playerName;
  //the currently selected card.
  private Card selectedCard;
  //the index of the selected card in the hand.
  private int selectedCardIndex = -1;
  private Appendable ap;
  private Features features;

  /**
   * Constructor for the PlayerPanel class. Sets up the panel to display the player's cards,
   * assigns the player's color, and adds a mouse listener to detect card clicks.
   *
   * @param hand       The list of cards in the player's hand.
   * @param color      The color associated with the player.
   * @param playerName The name or identifier of the player.
   */
  public PlayerPanel(List<Card> hand, Color color, String playerName) {
    this.playerHand = hand;
    this.playerColor = color;
    this.playerName = playerName;

    //set layout stack the cards vertically
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setPreferredSize(new Dimension(90, 120));  //adjust size as needed
    //add mouse listener to detect card clicks
    addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(MouseEvent e) {
        try {
          selectCard(e.getY());  //pass the Y coordinate of the mouse click
        } catch (IOException ex) {
          throw new RuntimeException(ex);
        }
      }
    });
  }

  public void setFeatures(Features features) {
    this.features = features;
  }


  /**
   * Custom paint method to draw the cards in the panel. Cards are stacked vertically,
   * and the selected card is highlighted with a border.
   *
   * @param g The Graphics object used for drawing.
   */
  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g;

    //get the available width and height for the cards
    int panelWidth = getWidth();
    int panelHeight = getHeight();
    int numCards = playerHand.size();

    if (numCards == 0) {
      return;  //no cards to draw
    }

    int cardHeight = panelHeight / numCards;
    int cardWidth = panelWidth;

    //calculate the total height of the cards with no gaps (stack them vertically)
    int totalCardHeight = numCards * cardHeight;

    //center the cards vertically if there's extra space
    int yOffset = (panelHeight - totalCardHeight) / 2;

    //draw each card in the player's hand
    for (int i = 0; i < playerHand.size(); i++) {
      Card card = playerHand.get(i);
      int x = (panelWidth - cardWidth) / 2;  //center the card horizontally
      int y = yOffset + i * cardHeight;  //adjust the y-position for each card

      //set the default background color for the card (unselected)
      g2.setColor(playerColor);
      g2.fillRect(x, y, cardWidth, cardHeight);

      //set background color and border for the selected card
      if (card == selectedCard) {
        g2.setColor(Color.DARK_GRAY);  //border color for selected card
        g2.setStroke(new BasicStroke(3));  //thick border for the selected card
        g2.drawRect(x, y, cardWidth, cardHeight);  //draw selected card's border
      } else {
        g2.setStroke(new BasicStroke(1));  //regular border for unselected cards
        g2.setColor(Color.BLACK);  //border color for unselected card
        g2.drawRect(x, y, cardWidth, cardHeight);  //draw unselected card's border
      }

      // Call the card's render method to draw the card's content
      card.render(g2, x, y, cardWidth, cardHeight);
    }
  }

  /**
   * Selects a card based on the vertical mouse position (Y coordinate).
   * If the clicked card is already selected, it deselects it. Otherwise, it selects the card.
   *
   * @param mouseY The Y coordinate of the mouse click within the panel.
   */
  //@Override
  private void selectCard(int mouseY) throws IOException {
    if (isEnabled()) {
      int numCards = playerHand.size();

      //calculate the card height based on the panel size
      int cardHeight = getHeight() / numCards;

      //calculate the offset to center the cards vertically
      int yOffset = (getHeight() - (cardHeight * numCards)) / 2;

      //adjust the mouseY coordinate by subtracting the yOffset
      int adjustedY = mouseY - yOffset;

      //calculate the index of the clicked card based on the adjusted Y position
      int index = adjustedY / cardHeight;

      if (index >= 0 && index < numCards) {
        Card clickedCard = playerHand.get(index);

        //if the clicked card is already selected, deselect it
        if (clickedCard == selectedCard) {
          selectedCard = null;
          selectedCardIndex = -1;
        } else {
          //select a new card
          selectedCard = clickedCard;
          selectedCardIndex = index;
        }
        repaint();  //repaint the panel to highlight the selected card

        // Notify features of the card selection
        if (features != null) {
          features.selectCard(selectedCardIndex, playerName);
        }
      }
    }
  }


  /**
   * Gets the currently selected card.
   *
   * @return The selected card, or null if no card is selected.
   */
  public Card getSelectedCard() {
    return selectedCard;
  }

  /**
   * Gets the index of the currently selected card.
   *
   * @return The index of the selected card, or -1 if no card is selected.
   */
  public int getSelectedCardIndex() {
    return selectedCardIndex;
  }

  public void updateHand(List<Card> newHand) {
    this.playerHand = newHand;
    this.selectedCard = null; // Reset selection
    this.selectedCardIndex = -1;
    this.repaint();
  }

  public void deselectCard() {
    // Reset the selected card and its index
    this.selectedCard = null;
    this.selectedCardIndex = -1;

    // Repaint to reflect the changes
    repaint();
  }

}