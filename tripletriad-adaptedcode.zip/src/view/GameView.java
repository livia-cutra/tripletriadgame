package view;

import java.util.List;

import model.Card;
import model.Cell;
import model.Player;

/**
 * GameView interface defines the methods that any game view (e.g., GUI or text-based view)
 * should implement to interact with the controller.
 */
public interface GameView {

  /**
   * Connects the view to the controller by setting the features (actions) the user can perform.
   *
   * @param features the Features object implemented by the controller
   */
  void setFeatures(Features features);

  /**
   * Updates the game board display based on the current state of the board.
   *
   * @param board the updated board as a 2D character array
   */
  void updateBoard(Cell[][] board);

  /**
   * Displays an error message to the user.
   *
   * @param message the error message to display
   */
  void showError(String message);

  void enableInteractions(boolean enable);


  void updateGameState(List<Card> hand, List<Card> hand1, Cell[][] boardA);

  void showMessage(String s);

  int getSelectedCardIndex(Player currPlayer);
}
