package view;

import model.Card;

/**
 * Represents the view component interface of the Triple Trios game.
 * Provides methods for rendering the current state of the game, including
 * the player, board, and hand of cards.
 *
 * @param <C> the type of Card used in the game
 */
public interface TTBViewInterface<C extends Card> {

  /**
   * Returns a string representation of the current game state, including
   * the current player, the game board, and the player's hand.
   *
   * @return a string displaying the grid, hand, and possibly the winner if the game is over.
   */
  String toString();
}
