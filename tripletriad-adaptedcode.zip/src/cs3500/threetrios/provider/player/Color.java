package cs3500.threetrios.provider.player;

/**
 * they did not provide us with a javadoc comment for this.
 */
public enum Color implements model.PlayerAction {
  Blue;

  /**
   * they did not provide us with a javadoc comment for this.
   * @param indexAtHand the index of the card to select
   * @return
   */
  @Override
  public model.Card selectCard(int indexAtHand) {
    return null;
  }
}
