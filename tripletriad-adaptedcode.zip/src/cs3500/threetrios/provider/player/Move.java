package cs3500.threetrios.provider.player;

import cs3500.threetrios.provider.model.ThreeTrioCard;

/**
 * Represents a move in the game. This move is represented by a row, column, and card.
 * Where the card is played to the row and column on the board.
 */
public interface Move {

  int getRow();

  int getCol();

  ThreeTrioCard getCard();
}