package cs3500.threetrios.provider.model;

/**
 * Enum to represent the directions where attack values are correlated to on a playable card.
 * Each playable card in the game will have an associated attack value in each of these directions.
 */
public enum Direction {
  NORTH, SOUTH, EAST, WEST
}
