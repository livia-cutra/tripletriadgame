package cs3500.threetrios.provider.view;

/**
 * Interface to represent the view of the game.
 */
public interface ThreeTrioView {

}
