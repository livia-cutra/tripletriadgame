package adapter;

import java.util.ArrayList;
import java.util.List;

import cs3500.threetrios.provider.model.ReadonlyThreeTrioModel;
import cs3500.threetrios.provider.player.Player;
import model.Card;
import model.Cell;
import model.Color;
import model.MutableTTB;

/**
 * An adapter class that bridges our MutableTTB model with the provider's ReadonlyThreeTrioModel.
 * It translates data and functionality between the two systems, allowing seamless integration
 * while adhering to the expected interfaces.
 */
public class CombinedModel implements ReadonlyThreeTrioModel<CombinedCard> {

  private boolean red;
  private MutableTTB ttb;

  /**
   * Constructs a CombinedModel instance.
   *
   * @param red indicates whether the player using this model is the red player
   * @param ttb the underlying game model
   */
  public CombinedModel(boolean red, MutableTTB ttb) {
    this.red = red;
    this.ttb = ttb;
  }

  /**
   * Checks if the game is over.
   *
   * @return true if the game is over; false otherwise
   */
  @Override
  public boolean isGameOver() {
    return ttb.isGameOver();
  }

  /**
   * Retrieves the winner of the game.
   *
   * @return the Color of the winning player
   */
  @Override
  public Color getWinner() {
    return ttb.getWinner().getColor();
  }

  /**
   * Gets the total number of tiles on the board.
   *
   * @return the number of tiles (not implemented, returns 0)
   */
  @Override
  public int getNumTiles() {
    return 0;
  }

  /**
   * Retrieves the current player's hand.
   *
   * @return a list of CombinedCard representing the player's hand
   */
  @Override
  public List<CombinedCard> getPlayerHand() {
    return List.of(); //placeholder, returns an empty list
  }

  /**
   * Retrieves the other player's hand.
   *
   * @return a list of CombinedCard representing the other player's hand
   */
  @Override
  public List<CombinedCard> getOtherPlayerHand() {
    return List.of(); // placeholder, returns an empty list
  }

  /**
   * Retrieves Player One's hand of cards.
   *
   * @return a list of CombinedCard for Player One
   */
  @Override
  public List<CombinedCard> getPlayerOneHand() {
    List<CombinedCard> combinedCards = new ArrayList<>();
    List<Card> hand = red ? ttb.getPlayerBlue().getHand() : ttb.getPlayerRed().getHand();
    for (Card card : hand) {
      combinedCards.add(new CombinedCard(card));
    }
    return combinedCards;
  }

  /**
   * Retrieves Player Two's hand of cards.
   *
   * @return a list of CombinedCard for Player Two
   */
  @Override
  public List<CombinedCard> getPlayerTwoHand() {
    List<CombinedCard> combinedCards = new ArrayList<>();
    List<Card> hand = red ? ttb.getPlayerRed().getHand() : ttb.getPlayerBlue().getHand();
    for (Card card : hand) {
      combinedCards.add(new CombinedCard(card));
    }
    return combinedCards;
  }

  /**
   * Retrieves the game board with cells represented as CombinedCard.
   *
   * @return a 2D array of CombinedCard representing the board
   */
  @Override
  public CombinedCard[][] getBoard() {
    Cell[][] board = ttb.getBoard();
    CombinedCard[][] combinedCards = new CombinedCard[board.length][board[0].length];
    for (int i = 0; i < board.length; i++) {
      for (int j = 0; j < board[i].length; j++) {
        if (board[i][j].isHole()) {
          combinedCards[i][j] = new CombinedCard(true);
        } else if (!board[i][j].isCard()) {
          combinedCards[i][j] = new CombinedCard(false);
        } else {
          try {
            Color color = board[i][j].getOwnerColor();
            CombinedCard card = new CombinedCard(board[i][j].getCard());
            card.switchOwner(new model.Player(color, List.of()));
            combinedCards[i][j] = card;
          } catch (IllegalArgumentException e) {
            combinedCards[i][j] = new CombinedCard(board[i][j].getCard());
          }
        }
      }
    }
    return combinedCards;
  }

  /**
   * Determines whose turn it is.
   *
   * @return true if it is the red player's turn; false otherwise
   */
  @Override
  public boolean getTurn() {
    return ttb.getCurrPlayer().getColor().equals(Color.RED) != red;
  }

  /**
   * Retrieves the card at the specified board position.
   *
   * @param row the row index
   * @param col the column index
   * @return the {@link CombinedCard} at the specified position
   */
  @Override
  public CombinedCard getCard(int row, int col) {
    return null; //placeholder, not implemented
  }

  /**
   * Retrieves the width of the board.
   *
   * @return the number of columns in the board
   */
  @Override
  public int getBoardW() {
    return getBoard()[0].length;
  }

  /**
   * Retrieves the height of the board.
   *
   * @return the number of rows in the board
   */
  @Override
  public int getBoardH() {
    return getBoard().length;
  }

  /**
   * Retrieves the color of the card at the specified position.
   *
   * @param row the row index
   * @param col the column index
   * @return the Color of the card at the position, or null if not applicable
   */
  @Override
  public Color getCardColor(int row, int col) {
    return null; // placeholder, not implemented, we do not have in our code
  }

  /**
   * Retrieves the score of a player based on their color.
   *
   * @param color the {@link Color} of the player
   * @return the player's score (not implemented, returns 0)
   */
  @Override
  public int getScore(Color color) {
    return 0;
  }

  /**
   * Counts the possible flips for a card placed at a given position.
   *
   * @param row  the row index
   * @param col  the column index
   * @param card the {@link CombinedCard} to place
   * @return the number of possible flips (not implemented, returns 0)
   */
  @Override
  public int countPossibleFlips(int row, int col, CombinedCard card) {
    return 0;
  }

  /**
   * Checks if a move is valid at the specified position.
   *
   * @param row the row index
   * @param col the column index
   * @return true if the move is valid; false otherwise
   */
  @Override
  public boolean isValidMove(int row, int col) {
    return false;
  }

  /**
   * Checks if the game has started.
   *
   * @return true if the game has started; false otherwise
   */
  @Override
  public boolean hasGameStarted() {
    return false; // placeholder, not implemented, we do not have in our code
  }

  /**
   * Retrieves the current player.
   *
   * @return the current Player
   */
  @Override
  public Player getCurrentPlayer() {
    return new CombinedPlayer(ttb.getCurrPlayer().getColor(), ttb.getCurrPlayer().getHand());
  }
}

