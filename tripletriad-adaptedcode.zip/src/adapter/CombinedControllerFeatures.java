package adapter;

import controller.ModelListener;
import controller.PlayerObserver;
import cs3500.threetrios.provider.controller.ThreeTrioControllerFeatures;
import cs3500.threetrios.provider.view.ThreeTrioGuiFeatures;
import cs3500.threetrios.provider.view.ThreeTrioGuiView;
import model.Color;
import model.MutableTTB;
import view.GameView;

/**
 * A combined controller class that implements multiple interfaces to bridge the functionality
 * of our game components with the provider's system. It acts as an adapter to integrate the
 * provider's features with our existing model and view.
 */
public class CombinedControllerFeatures implements
        ThreeTrioControllerFeatures, ThreeTrioGuiFeatures, ModelListener {

  private MutableTTB model;
  private ThreeTrioGuiView view;
  private boolean red;
  private int cardIdx;
  private PlayerObserver player;

  /**
   * Constructs a CombinedControllerFeatures instance with the specified player, model, and view.
   * This controller integrates the player's actions, game model, and view to handle game events.
   *
   * @param player the player observer associated with this controller
   * @param model  the mutable game model
   * @param view   the GUI view for the player
   */
  public CombinedControllerFeatures(PlayerObserver<Color> player, MutableTTB model,
                                    ThreeTrioGuiView view) {
    this.model = model;
    this.view = view;
    this.player = player;
  }

  /**
   * Notifies the view to refresh when a play occurs.
   */
  @Override
  public void notifyPlay() {
    view.refresh();
  }

  /**
   * Displays the winner notification on the view when the game ends.
   */
  @Override
  public void notifyWinner() {
    view.notify("Your Winner is: " + model.getWinner());
  }

  /**
   * Refreshes the view to reflect the current state of the game.
   */
  @Override
  public void refresh() {
    view.refresh();
  }

  /**
   * Handles card selection for a player. Updates the view with the selected card
   * and ensures only the current player can make a selection.
   *
   * @param cardIdx     the index of the selected card
   * @param isPlayerOne true if the player is Player 1, false otherwise
   */
  @Override
  public void selectCard(int cardIdx, boolean isPlayerOne) {
    if (model.getCurrPlayer().getColor().equals(player.getColor())) {
      this.cardIdx = cardIdx;
      if (!isPlayerOne) {
        view.selectP1Card(cardIdx);
      } else {
        view.selectP2Card(cardIdx);
      }
      refresh();
    } else {
      view.notify("Not Your Turn");
    }
  }

  /**
   * Returns the username of the current player.
   *
   * @return an empty string (stub, we do not use this in our implementation)
   */
  @Override
  public String getUsername() {
    return "";
  }

  /**
   * Places a card on the board at the specified position. Only allows the current player
   * to perform the action. Updates the game state and refreshes the view.
   *
   * @param row     the row index on the board
   * @param col     the column index on the board
   * @param cardIdx the index of the card to be placed
   */
  @Override
  public void playToBoard(int row, int col, int cardIdx) {
    if (model.getCurrPlayer().getColor().equals(player.getColor())) {
      model.placeCardTTB(row, col, cardIdx);
      model.nextTurn();
      refresh();
    } else {
      view.notify("Not Your Turn");
    }
  }

  /**
   * Handles the event when it's a player's turn. Refreshes the view.
   *
   * @param playerName the name of the player whose turn it is
   */
  @Override
  public void onPlayerTurn(String playerName) {
    view.refresh();
  }

  /**
   * Handles the event when the game is over. Displays the winner notification.
   *
   * @param winnerName the name of the winning player
   */
  @Override
  public void onGameOver(String winnerName) {
    view.refresh();
    notifyWinner();
  }

  /**
   * Retrieves the associated game view.
   *
   * @return null (placeholder implementation, we do not use this in our implementation)
   */
  @Override
  public GameView getView() {
    return null;
  }
}

