package adapter;

import java.util.HashMap;

import cs3500.threetrios.provider.model.Attack;
import cs3500.threetrios.provider.model.Direction;
import cs3500.threetrios.provider.model.ThreeTrioCard;
import model.Card;
import model.Color;

/**
 * Represents a combined card that adapts our Card class to the provider's ThreeTrioCard interface.
 * This class supports both systems by bridging their data formats and functionality,
 * including translating directional values to Attack objects and handling special cases like holes.
 */
public class CombinedCard extends Card implements ThreeTrioCard {
  HashMap<Direction, Attack> map;
  private boolean hole;

  /**
   * Constructs a Card with a specified name, owner, and directional values.
   *
   * @param name     the unique identifier for the card
   * @param northVal the value representing the north direction
   * @param southVal the value representing the south direction
   * @param westVal  the value representing the west direction
   * @param eastVal  the value representing the east direction
   */
  public CombinedCard(String name, int northVal, int southVal, int westVal, int eastVal) {
    super(name, northVal, southVal, westVal, eastVal);

    map = new HashMap<>();
    map.put(Direction.NORTH, translateAttack(getNorthVal()));
    map.put(Direction.SOUTH, translateAttack(getSouthVal()));
    map.put(Direction.EAST, translateAttack(getEastVal()));
    map.put(Direction.WEST, translateAttack(getWestVal()));


    this.hole = false;
  }

  /**
   * Constructs a CombinedCard by adapting an existing Card.
   *
   * @param card the card to adapt
   */
  public CombinedCard(Card card) {
    super(card.getName(), card.getNorthVal(), card.getSouthVal(), card.getWestVal(),
            card.getEastVal());
    super.setCard(card);
    map = new HashMap<>();
    map.put(Direction.NORTH, translateAttack(getNorthVal()));
    map.put(Direction.SOUTH, translateAttack(getSouthVal()));
    map.put(Direction.EAST, translateAttack(getEastVal()));
    map.put(Direction.WEST, translateAttack(getWestVal()));
    this.hole = false;
  }

  /**
   * Constructs a CombinedCard that represents a hole on the board.
   *
   * @param hole whether this card is a hole
   */
  public CombinedCard(boolean hole) {
    super("", 0, 0, 0, 0);
    this.hole = hole;
  }

  /**
   * Translates an integer value to the corresponding Attack value.
   *
   * @param a the integer value to translate
   * @return the corresponding Attack value
   */
  public static Attack translateAttack(int a) {
    if (a == 1) {
      return Attack.ONE;
    }
    if (a == 2) {
      return Attack.TWO;
    }
    if (a == 3) {
      return Attack.THREE;
    }
    if (a == 4) {
      return Attack.FOUR;
    }
    if (a == 5) {
      return Attack.FIVE;
    }
    if (a == 6) {
      return Attack.SIX;
    }
    if (a == 7) {
      return Attack.SEVEN;
    }
    if (a == 8) {
      return Attack.EIGHT;
    }
    if (a == 9) {
      return Attack.NINE;
    }
    return Attack.A;

  }

  /**
   * Gets the color of the card's owner.
   *
   * @return the color of the card's owner, or null if the card is unowned
   */
  @Override
  public Color getColor() {
    try {
      return getOwnerColor();
    } catch (IllegalStateException e) {
      return null;
    }
  }

  /**
   * Sets the color of the card's owner.
   * This method is not implemented and serves as a placeholder.
   *
   * @param color the color to set
   */
  @Override
  public void setColor(Color color) {
    //stub
  }

  /**
   * Returns a short string representation of the card.
   * This method is not implemented and currently returns an empty string.
   *
   * @return an empty string
   */
  @Override
  public String shortString() {
    return "";
  }

  /**
   * Returns the directional attacks of the card as a map.
   *
   * @return a HashMap mapping Direction to Attack
   */
  @Override
  public HashMap<Direction, Attack> getAttacks() {
    return map;
  }

  /**
   * Creates a deep copy of the card.
   * This method is a stub.
   *
   * @return null
   */
  @Override
  public ThreeTrioCard deepCopy() {
    return null;
  }

  /**
   * Checks if the card represents a hole.
   *
   * @return true if the card is a hole, false otherwise
   */
  public boolean isHole() {
    return hole;
  }
}
