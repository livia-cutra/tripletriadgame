package adapter;

import java.util.List;

import cs3500.threetrios.provider.model.ReadonlyThreeTrioModel;
import cs3500.threetrios.provider.view.GuiGameView;
import cs3500.threetrios.provider.view.ThreeTrioGuiFeatures;
import model.Card;
import model.Cell;
import model.Player;
import view.Features;
import view.GameView;

/**
 * Adapter class that bridges the GameView interface with the provider's ThreeTrioGuiView.
 * This class allows integration between our codebase and the provider's view implementation.
 */
public class ProviderViewAdapter extends GuiGameView implements GameView {

  /**
   * Constructs a ProviderViewAdapter with the given model and player.
   *
   * @param model  the ReadonlyThreeTrioModel instance representing the game state
   * @param player the cs3500.threetrios.provider.player.Player instance for the provider's view
   */
  public ProviderViewAdapter(ReadonlyThreeTrioModel model, cs3500.threetrios.provider.player.Player
          player) {
    super(model, player);
  }

  /**
   * Sets the Features interface to handle user interactions.
   * This method also adapts the features to align with the provider's ThreeTrioGuiFeatures.
   *
   * @param features the Features interface for our application's actions
   */
  @Override
  public void setFeatures(Features features) {
    // Wrap our Features in provider's ThreeTrioGuiFeatures
    ThreeTrioGuiFeatures providerFeatures = new ThreeTrioGuiFeatures() {
      @Override
      public void playToBoard(int row, int col, int cardIdx) {
        features.selectCell(row, col); // Map playToBoard to selectCell
      }
    };

    // Add features listener to the provider's view
    addFeaturesListener(providerFeatures);
  }

  /**
   * Updates the board's display based on the given state.
   * Since the provider's view doesn't directly update with a board, this calls refresh().
   *
   * @param board the updated Cell[][] array representing the board state
   */
  @Override
  public void updateBoard(Cell[][] board) {
    refresh();
  }

  /**
   * Displays an error message to the user.
   *
   * @param message the error message to display
   */
  @Override
  public void showError(String message) {
    notify(message);
  }

  /**
   * Enables or disables interactions with the view.
   * Currently, this method is a placeholder with no implementation.
   *
   * @param enable true to enable interactions, false to disable them
   */
  @Override
  public void enableInteractions(boolean enable) {
    // No implementation in the provider's view
  }

  /**
   * Updates the game state by refreshing the view.
   *
   * @param hand   the player's current hand of cards
   * @param hand1  the opponent's current hand of cards
   * @param boardA the updated Cell[][] array representing the board state
   */
  @Override
  public void updateGameState(List<Card> hand, List<Card> hand1, Cell[][] boardA) {
    refresh();
  }

  /**
   * Displays a general message to the user.
   * Currently, this method is a placeholder with no implementation.
   *
   * @param s the message to display
   */
  @Override
  public void showMessage(String s) {
    // No implementation
  }

  /**
   * Retrieves the index of the currently selected card for the given player.
   * Currently, this method returns -1 as a default value.
   *
   * @param currPlayer the Player whose selected card index is requested
   * @return the index of the selected card, or -1 if no card is selected
   */
  @Override
  public int getSelectedCardIndex(Player currPlayer) {
    return -1;
  }
}

