package adapter;

import java.util.List;

import cs3500.threetrios.provider.player.Move;
import model.Card;
import model.Color;

/**
 * An adapter class that bridges the model.Player class with the provider's cs3500.threetrios.
 * provider.player.Player interface. This class adapts the methods to align with the expectations
 * of the provider's system while retaining the functionality of the original Player model.
 */
public class CombinedPlayer extends model.Player implements
        cs3500.threetrios.provider.player.Player {

  /**
   * Constructs a CombinedPlayer instance with a specified color and a hand of cards.
   *
   * @param color the Color representing the player's team (RED or BLUE)
   * @param hand  the list of Card objects representing the player's hand
   */
  public CombinedPlayer(Color color, List<Card> hand) {
    super(color, hand);
  }

  /**
   * Retrieves the name of the player.
   * Currently, this method returns an empty string as a placeholder.
   *
   * @return an empty string
   */
  @Override
  public String getName() {
    return "";
  }

  /**
   * Retrieves the next move of the player.
   * Currently, this method returns null as it is not implemented.
   *
   * @return null
   */
  @Override
  public Move getMove() {
    return null;
  }
}

