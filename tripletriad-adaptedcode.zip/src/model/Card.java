package model;

import java.awt.Graphics2D;

/**
 * Class that represents a Card in the game.
 * Each card has associated values for its directional movements,
 * an owner (representing the player), and its position on the board.
 */
public class Card extends Cell {
  private String name; // unique identifier for the card
  private int northVal;
  private int southVal;
  private int westVal;
  private int eastVal;


  /**
   * Constructs a Card with a specified name, owner, and directional values.
   *
   * @param name     the unique identifier for the card
   * @param northVal the value representing the north direction
   * @param southVal the value representing the south direction
   * @param westVal  the value representing the west direction
   * @param eastVal  the value representing the east direction
   *
   */
  public Card(String name, int northVal, int southVal,
              int westVal, int eastVal) {
    this.name = name;
    this.northVal = northVal;
    this.southVal = southVal;
    this.westVal = westVal;
    this.eastVal = eastVal;
  }

  /**
   * Retrieves the name of the card.
   *
   * @return the unique identifier for the card
   */
  public String getName() {
    return name;
  }

  /**
   * Retrieves the value for the north direction.
   *
   * @return the north value of the card
   */
  public int getNorthVal() {
    return northVal;
  }

  /**
   * Retrieves the value for the south direction.
   *
   * @return the south value of the card
   */
  public int getSouthVal() {
    return southVal;
  }

  /**
   * Retrieves the value for the west direction.
   *
   * @return the west value of the card
   */
  public int getWestVal() {
    return westVal;
  }

  /**
   * Retrieves the value for the east direction.
   *
   * @return the east value of the card
   */
  public int getEastVal() {
    return eastVal;
  }

  /**
   * Renders the card values (north, south, east, west) onto the board.
   * @param g2 the Graphics2D object
   * @param x the x-coordinate of the top-left corner of the cell
   * @param y the y-coordinate of the top-left corner of the cell
   * @param width the width of the cell
   * @param height the height of the cell
   *
   */
  public void render(Graphics2D g2, int x, int y, int width, int height) {
    g2.setColor(java.awt.Color.BLACK);

    //draw each value at the appropriate location within the cell
    g2.drawString(valueToString(northVal), x + width / 2 - 10, y + 15); //north
    g2.drawString(valueToString(southVal), x + width / 2 - 10, y + height - 5); //south
    g2.drawString(valueToString(eastVal), x + width - 15, y + height / 2); //east
    g2.drawString(valueToString(westVal), x + 5, y + height / 2); //west
  }

  /**
   * Converts an integer value to its corresponding string representation.
   * If the value is 10, it returns "A" (typically used for card games).
   * For other values, it returns the string representation of the integer.
   *
   * @param value the integer value to be converted
   * @return the string representation of the value, with 10 replaced by "A"
   */
  private String valueToString(int value) {
    return (value == 10) ? "A" : String.valueOf(value);
  }

}
