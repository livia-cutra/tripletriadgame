package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import controller.ModelListener;

/**
 * This represents a Triple Triad Game.
 * This game features ways to manipulate the game as well as a board for the game.
 *
 * <p>Class Invariant: The game can either be in progress or over, but not both at the same time.
 * 'gameStarted` and `gameOver` cannot both be true simultaneously.</p>
 *
 * @param <C> An extendable for Card
 */
public class TTB<C extends Cell> implements MutableTTB, ModelFeatures {
  private int rows;
  private int cols;
  private Cell[][] board;
  private Random rand = new Random();
  private boolean gameOver;
  private boolean gameStarted;

  private Player playerRed;
  private Player playerBlue;
  private boolean playerRedTurn;

  private int availableSpaces;
  private int[] flipCount = new int[]{0};

  //new
  private List<ModelListener> listeners = new ArrayList<>();
  private String currentPlayer; // Tracks whose turn it is
  private String winner;

  /**
   * Constructs a Board with a specified Random object.
   *
   * @param rand the Random object used for shuffling cards
   */
  public TTB(Random rand) {
    this.rand = rand;
  }

  /**
   * Constructs a Board with specified dimensions.
   *
   * @param rows the number of rows in the board
   * @param cols the number of columns in the board
   */
  public TTB(int rows, int cols) {
    this.rows = rows;
    this.cols = cols;
  }

  /**
   * Constructs a new instance of the TTB game with the specified initial board setup and player
   * hands. Each cell in the new game board is independently created based on the state of the
   * corresponding cell in the provided board to avoid direct reference sharing, ensuring game state
   * encapsulation.
   *
   * @param board    the initial configuration of the game board as a 2D array of Cells
   * @param redHand  the list of cards in the red player's hand
   * @param blueHand the list of cards in the blue player's hand
   */

  public TTB(Cell[][] board, List<Card> redHand, List<Card> blueHand) {
    this.board = new Cell[board.length][board[0].length];
    for (int i = 0; i < board.length; i++) {
      for (int j = 0; j < board[0].length; j++) {
        this.board[i][j] = new Cell(board[i][j]);
      }
    }
    List<Card> rHand = new ArrayList<>(redHand);
    List<Card> bHand = new ArrayList<>(blueHand);
    this.playerRed = new Player(Color.RED, rHand);
    this.playerBlue = new Player(Color.BLUE, bHand);
    this.rows = board.length;
    this.cols = board[0].length;
    gameStarted = true;
  }

  /**
   * Starts the game by initializing the board and dealing cards to players.
   *
   * @param rows     the number of rows in the board
   * @param cols     the number of columns in the board
   * @param readGrid a 2D array representing the initial board state
   * @param cards    a list of card descriptions
   * @param shuffle  whether to shuffle the cards before dealing
   * @throws IllegalArgumentException if there are not enough cards for the available spaces
   */
  public void startGame(int rows, int cols, char[][] readGrid, List<String> cards,
                        boolean shuffle) {
    //implementation enforces invariant
    if (gameOver) {
      throw new IllegalStateException("Game already is over");
    }

    this.rows = rows;
    this.cols = cols;
    this.availableSpaces = 0;

    //create the board
    createBoard(readGrid);

    //creating all of the cards
    List<Card> allCards = createCards(cards);
    // its based on how many available spaces there are
    if (allCards.size() < (availableSpaces / 2) * 2 + 2) {
      throw new IllegalArgumentException("There are " + availableSpaces
              + " available spaces and only " + allCards.size() + " cards");
    }
    if (shuffle) {
      Collections.shuffle(allCards, rand);
    }
    //dealing cards to each player
    int cardsPerPlayer = availableSpaces / 2;
    if (availableSpaces % 2 == 1) {
      cardsPerPlayer++;
    }

    List<Card> redList = new ArrayList<>();
    List<Card> blueList = new ArrayList<>();
    for (int i = 0; i < cardsPerPlayer; i++) {
      redList.add(allCards.get(i));
    }
    for (int i = cardsPerPlayer; i < 2 * cardsPerPlayer; i++) {
      blueList.add(allCards.get(i));
    }

    playerRed = new Player(Color.RED, redList);

    playerBlue = new Player(Color.BLUE, blueList);

    playerRedTurn = true;
    currentPlayer = "RED"; //initialize currentPlayer to match playerRedTurn

    winner = null;
    gameOver = false;
    gameStarted = true;
    isGameOver();
  }

  /**
   * Creates the board based on the provided grid representation.
   *
   * @param readGrid a 2D array representing the initial state of the board
   */
  private void createBoard(char[][] readGrid) {
    board = new Cell[rows][cols];
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        if (readGrid[i][j] == 'X') {
          board[i][j] = new Cell(true);
        } else {
          board[i][j] = new Cell(); //recently added trying to fix null problem
          availableSpaces++;
        }
      }
    }
  }

  /**
   * Creates a list of Card objects from the provided card descriptions.
   *
   * @param cards a list of card descriptions
   * @return a list of created Card objects
   */
  private List<Card> createCards(List<String> cards) {
    List<Card> cardList = new ArrayList<Card>();
    for (int i = 0; i < cards.size(); i += 5) {
      int northInt;
      int southInt;
      int eastInt;
      int westInt;
      if (cards.get(i + 1).equals("A")) {
        northInt = 10;
      } else {
        northInt = Integer.parseInt(cards.get(i + 1));
      }
      if (cards.get(i + 2).equals("A")) {
        southInt = 10;
      } else {
        southInt = Integer.parseInt(cards.get(i + 2));
      }
      if (cards.get(i + 3).equals("A")) {
        eastInt = 10;
      } else {
        eastInt = Integer.parseInt(cards.get(i + 3));
      }
      if (cards.get(i + 4).equals("A")) {
        westInt = 10;
      } else {
        westInt = Integer.parseInt(cards.get(i + 4));
      }
      Card c = new Card(cards.get(i), northInt, southInt, eastInt, westInt);
      cardList.add(c);
    }
    return cardList;
  }

  /**
   * Retrieves the card at the specified row and column.
   *
   * @param row the row of the card
   * @param col the column of the card
   * @return the Card object at the specified position, or null if there is no card
   */
  public Card getCardTTB(int row, int col) {
    //check if the provided row and column are within bounds
    if (row < 0 || row >= rows || col < 0 || col >= cols) {
      throw new IllegalArgumentException("Row or column is out of bounds");
    }
    BoardPiece piece = board[row][col];
    if (piece instanceof Card) {
      return (Card) piece;
    }
    //return null if there is no Card at the specified position (so it is either empty or a hole)
    return null;
  }

  /**
   * Retrieves the number of rows in the board.
   *
   * @return the number of rows in the board
   */
  public int getRows() {
    return rows;
  }

  /**
   * Retrieves the number of columns in the board.
   *
   * @return the number of columns in the board
   */
  public int getCols() {
    return cols;
  }

  /**
   * Retrieves the current state of the board as a 2D array of BoardPiece objects.
   *
   * @return a 2D array representing the current state of the board
   */
  public Cell[][] getBoard() {
    return board;
  }

  /**
   * Retrieves the player representing the red team.
   *
   * @return the Player object representing the red player
   */
  public Player getPlayerRed() {
    return playerRed;
  }

  /**
   * Retrieves the player representing the blue team.
   *
   * @return the Player object representing the blue player
   */
  public Player getPlayerBlue() {
    return playerBlue;
  }

  /**
   * Places a card on the game board at the specified column and row.
   *
   * @param col     the column where the card is to be placed
   * @param row     the row where the card is to be placed
   * @param handIdx the Idx of  the Card object to be placed on the board from the hand
   * @throws IllegalArgumentException if the position is out of bounds, is a hole,
   *                                  or is occupied by another card
   */
  public void placeCardTTB(int row, int col, int handIdx) {
    if (handIdx < 0 || handIdx >= getCurrPlayer().getHand().size()) {
      throw new IllegalArgumentException("hand index out of bounds");
    }
    if (row < 0 || row >= rows || col < 0 || col >= cols) {
      throw new IllegalArgumentException("Row or column is out of bounds");
    }

    if (isLegalMove(row, col)) {

      Card c = getCurrPlayer().removeCard(handIdx);

      board[row][col].switchOwner(getCurrPlayer());
      //place the card in the cell at the specified location
      board[row][col].placeCard(c, getCurrPlayer());
      boolean[][] visited = new boolean[this.rows][this.cols];
      visited[row][col] = true;
      battlePhase(row, col, visited, flipCount);
      availableSpaces--;
      isGameOver();
    }
  }


  /**
   * Checks if the game is over or not.
   *
   * @return whether the game is over
   */
  public boolean isGameOver() {
    if (availableSpaces <= 0) {
      gameOver = true;
      getWinner();
      notifyGameOver(winner);
    }
    return gameOver;
  }

  /**
   * Conducts the battle phase where a newly placed card interacts with existing cards on the board.
   *
   * @param row     The row index of the newly placed card.
   * @param col     The column index of the newly placed card.
   * @param visited Tells if the cell ahs been visited or not.
   * @throws IllegalStateException if the game is over or has not started.
   */
  private void battlePhase(int row, int col, boolean[][] visited, int[] flipCount) {
    //implementation enforces invariant, game cannot be over
    if (gameOver) {
      throw new IllegalStateException("The game is over.");
    }
    //implementation enforces invariant, game has to be started
    if (!gameStarted) {
      throw new IllegalStateException("The game has not started.");
    }

    visited[row][col] = true;
    Card currCard = board[row][col].getCard();
    if (row - 1 >= 0 && board[row - 1][col].isCard() && !visited[row - 1][col]) {
      if (currCard.getNorthVal() > board[row - 1][col].getCard().getSouthVal()) {
        board[row - 1][col].switchOwner(getCurrPlayer());
        flipCount[0]++; //increment flip count
        battlePhase(row - 1, col, visited, flipCount);
      }
    }
    if (row + 1 < rows && board[row + 1][col].isCard() && !visited[row + 1][col]) {
      if (currCard.getSouthVal() > board[row + 1][col].getCard().getNorthVal()) {
        board[row + 1][col].switchOwner(getCurrPlayer());
        flipCount[0]++; //increment flip count
        battlePhase(row + 1, col, visited, flipCount);
      }
    }
    if (col - 1 >= 0 && board[row][col - 1].isCard() && !visited[row][col - 1]) {
      if (currCard.getWestVal() > board[row][col - 1].getCard().getEastVal()) {
        board[row][col - 1].switchOwner(getCurrPlayer());
        flipCount[0]++; //increment flip count
        battlePhase(row, col - 1, visited, flipCount);
      }
    }
    if (col + 1 < cols && board[row][col + 1].isCard() && !visited[row][col + 1]) {
      if (currCard.getEastVal() > board[row][col + 1].getCard().getWestVal()) {
        board[row][col + 1].switchOwner(getCurrPlayer());
        flipCount[0]++; //increment flip count
        battlePhase(row, col + 1, visited, flipCount);
      }
    }
  }

  /**
   * Counts the number of cards that would be flipped if a card were placed at the given coordinate.
   *
   * @param row The row index of the newly placed card.
   * @param col The column index of the newly placed card.
   * @return The total number of cards that would be flipped.
   */
  public int countFlippedCards(int row, int col) {
    boolean[][] visited = new boolean[rows][cols]; //initialize visited array
    //array to store the total flipped count (since Java passes objects by reference)
    flipCount = new int[1];
    battlePhase(row, col, visited, flipCount); //call battlePhase to calculate flips
    return flipCount[0]; //return the final count of flipped cards
  }

  /**
   * Proceeds to the next turn, switching the current player.
   *
   * @throws IllegalStateException if the game is over or has not started.
   */
  public void nextTurn() {
    //implementation enforces variant
    if (gameOver) {
      notifyGameOver(winner);
      //throw new IllegalStateException("Cannot proceed to the next turn, the game is over.");
    }
    //implementation enforces variant
    if (!gameStarted) {
      throw new IllegalStateException("Cannot proceed to the next turn, the game has not started.");
    }

    playerRedTurn = !playerRedTurn; // Toggle turn
    currentPlayer = playerRedTurn ? "RED" : "BLUE"; // Update currentPlayer to match turn
    notifyPlayerTurn(currentPlayer); // Notify listeners of the current turn
  }

  /**
   * Gets the current player of the game, whichever player has their turn right now.
   *
   * @return the player that has their turn currently
   */
  public Player getCurrPlayer() {
    return playerRedTurn ? playerRed : playerBlue;
  }

  /**
   * Retrieves the number of available spaces in the current context.
   *
   * @return the number of available spaces as an integer
   */
  @Override
  public int getAvailableSpaces() {
    return availableSpaces;
  }

  /**
   * Gets the current player of the game and returns its name as a string value,
   * whichever player has their turn right now.
   *
   * @return the name of the player that has their turn currently
   */
  public String getPlayerString() {
    if (playerRedTurn) {
      return "RED";
    } else {
      return "BLUE";
    }
  }

  /**
   * Gets the winner of the game.
   *
   * @return the player that won, if it is a draw, returns null
   */
  public Player getWinner() {
    if (gameOver) {
      int redOwns = 0;
      int blueOwns = 0;
      for (int i = 0; i < board.length; i++) {
        for (int j = 0; j < board[0].length; j++) {
          if (board[i][j].isCard()) {
            Cell cardInCell = board[i][j];
            if (cardInCell.getOwnerColor().equals(Color.RED)) {
              redOwns++;
            } else {
              blueOwns++;
            }
          }
        }
      }
      if (redOwns > blueOwns) {
        winner = "RED";
        return playerRed;
      }
      if (blueOwns > redOwns) {
        winner = "BLUE";
        return playerBlue;
      }
      winner = "Draw";
      return null;
    } else {
      throw new IllegalStateException("No winner");
    }
  }

  /**
   * Returns the color of the player who owns the card at the given coordinates.
   *
   * @return the color of the card owner
   * @throws IllegalStateException if no owner is set for the cell
   */
  public Color getCardOwner(int row, int col) {
    if (board[row][col].isCard()) {
      return board[row][col].getOwnerColor();
    }
    return null;
  }

  /**
   * Checks whether a move is legal based on the state of a specific cell on the board.
   * A move is legal if the cell is not a hole and does not contain a card.
   *
   * @param row The row index of the cell to check.
   * @param col The column index of the cell to check.
   * @return true if the move is legal (the cell is not a hole or a card), false otherwise.
   */
  public boolean isLegalMove(int row, int col) {
    return !board[row][col].isHole() && !board[row][col].isCard();
  }

  /**
   * Calculates the current score of a player based on the number of cards in their hand
   * and the number of cards they own on the board. The score is the total number of cards the
   * player has in their hand, plus the number of cards on the board that are owned by the player
   * (cards whose owner color matches the player's color).
   *
   * @param player The player whose score is to be calculated.
   * @return total score of player, which is sum of player's hand size and owned cards on the board.
   */
  public int getPlayerScore(Player player) {
    int score = player.getHand().size();
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        if (board[i][j].isCard() && board[i][j].getOwnerColor().equals(player.getColor())) {
          score++;
        }
      }
    }
    return score;
  }

  /**
   * Notifies all registered listeners when it is a player's turn.
   *
   * @param playerName the name of the player whose turn it is
   */
  @Override
  public void notifyPlayerTurn(String playerName) {
    for (ModelListener listener : listeners) {
      listener.onPlayerTurn(playerName);
    }
  }

  /**
   * Notifies all registered listeners that the game has ended and provides the winner's name.
   *
   * @param winnerName the name of the player who won the game, or null if it's a draw
   */
  @Override
  public void notifyGameOver(String winnerName) {
    for (ModelListener listener : listeners) {
      listener.onGameOver(winner);
    }
  }

  /**
   * Adds a listener to the model for receiving event notifications.
   *
   * @param listener the {@link ModelListener} to be registered
   */
  @Override
  public void addModelListener(ModelListener listener) {
    listeners.add(listener);
  }

}
