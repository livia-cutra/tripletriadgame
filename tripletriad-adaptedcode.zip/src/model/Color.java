package model;

/**
 * The color of the card representing the player, which could only be red or blue.
 */
public enum Color {
  RED, BLUE;

  /**
   * Takes in the color and returns it as a string.
   * @return a String
   */
  public String toString() {
    if (this == Color.RED) {
      return "Red";
    }
    return "Blue";
  }
}


