import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import model.Card;
import model.TTB;
import view.TTBView;

/**
 * A way to interactively play the game on a console.
 */
public class MainTTB {
  /**
   * Set up the game to play.
   *
   * @param args representing the args
   */
  public static void main(String[] args) {

    //sample board
    String board =
            "5 7\n"
                    +
                    "CCXXXXC\n"
                    +
                    "CXCXXXC\n"
                    +
                    "CXXCXXC\n"
                    +
                    "CXXXCXC\n"
                    +
                    "CXXXXCC";

    //sample cards
    String cards = "CorruptKing 7 3 9 A\n"
            +
            "AngryDragon 2 8 9 9\n"
            +
            "WindBird 7 2 5 3\n"
            +
            "HeroKnight A 2 4 4\n"
            +
            "WorldDragon 8 3 5 7\n"
            +
            "SkyWhale 4 5 9 9\n"
            +
            "CorruptKing 7 3 9 A\n"
            +
            "AngryDragon 2 8 9 9\n"
            +
            "WindBird 7 2 5 3\n"
            +
            "HeroKnight 10 2 4 4\n"
            +
            "WorldDragon 8 3 5 7\n"
            +
            "SkyWhale 4 5 9 9\n"
            +
            "CorruptKing 7 3 9 A\n"
            +
            "AngryDragon 2 8 9 9\n"
            +
            "WindBird 7 2 5 3\n"
            +
            "HeroKnight A 2 4 4\n"
            +
            "WorldDragon 8 3 5 7\n"
            +
            "SkyWhale 4 5 9 9\n";

    Scanner scan = new Scanner(board); // this some grid configuration file
    int r = scan.nextInt();
    int c = scan.nextInt();
    char[][] boardArray = new char[r][c];
    for (int i = 0; i < r; i++) {
      String str = scan.next();
      for (int j = 0; j < c; j++) {
        boardArray[i][j] = str.charAt(j);
      }
    }

    scan = new Scanner(cards);
    ArrayList<String> cardList = new ArrayList<String>();
    while (scan.hasNext()) {
      cardList.add(scan.next());
    }
    Random seed = new Random(2);
    TTB<Card> bd = new TTB<Card>(seed);
    bd.startGame(r, c, boardArray, cardList, false);

    TTBView<Card> ttw = new TTBView(bd, new StringBuilder());
    System.out.println(ttw.toString());
    bd.placeCardTTB(0, 0, 0);
    System.out.println(ttw.toString());
    bd.nextTurn();
    System.out.println(ttw.toString());
    bd.placeCardTTB(1, 0, 1);
    System.out.println(ttw.toString());
    bd.nextTurn();
    System.out.println(ttw.toString());
    bd.placeCardTTB(2, 0, 0);
    System.out.println(ttw.toString());


  }

}
