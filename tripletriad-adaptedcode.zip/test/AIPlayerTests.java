import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import controller.AIPlayer;
import model.Card;
import model.Cell;
import model.Color;
import model.MockModel;
import model.Player;

/**
 * Unit tests for the AIPlayer class. These tests verify the functionality of the AI's
 * decision-making logic using various scenarios, including prioritization of corner moves,
 * handling of holes, and greedy strategies.
 */
public class AIPlayerTests {

  // Fields used in tests
  Cell[][] noHoles3x3;
  MockModel model3x3;
  Card c1;
  Card c2;
  Card c3;
  Card c4;
  Card c5;
  Player red;
  Player blue;
  AIPlayer ai;

  /**
   * Sets up the initial state for each test case. Initializes a 3x3 board with no holes,
   * creates sample cards, and sets up red and blue players with these cards. Also initializes
   * a mock model and an AIPlayer for testing.
   */
  @Before
  public void setUp() {
    noHoles3x3 = new Cell[3][3];
    for (int i = 0; i < noHoles3x3.length; i++) {
      for (int j = 0; j < noHoles3x3[i].length; j++) {
        noHoles3x3[i][j] = new Cell();
      }
    }
    c1 = new Card("c1", 1, 1, 1, 1);
    c2 = new Card("c2", 1, 1, 1, 1);
    c3 = new Card("c3", 1, 1, 1, 1);
    c4 = new Card("c4", 1, 1, 1, 1);
    c5 = new Card("c5", 1, 1, 1, 1);
    red = new Player(Color.RED, new ArrayList<>(Arrays.asList(c1, c2, c3, c4, c5)));
    blue = new Player(Color.BLUE, new ArrayList<>(Arrays.asList(c1, c2, c3, c4, c5)));

    model3x3 = new MockModel(noHoles3x3, red, blue);
    ai = new AIPlayer(model3x3, Color.BLUE, "strategy_1");
  }

  /**
   * Tests if the AI correctly prioritizes corner moves when available.
   */
  @Test
  public void testPrioritizeCorners() {
    noHoles3x3[1][1].placeCard(c1, red);
    Assert.assertEquals(ai.determineMove(), new ArrayList<>(Arrays.asList(0, 0, 0)));
  }

  /**
   * Tests if the AI chooses corner moves in the correct order when they are available sequentially.
   */
  @Test
  public void testCornersGoInOrder() {
    Assert.assertEquals(ai.determineMove(), new ArrayList<>(Arrays.asList(0, 0, 0)));
    noHoles3x3[0][0].placeCard(c1, blue);
    Assert.assertEquals(ai.determineMove(), new ArrayList<>(Arrays.asList(0, 2, 0)));
    noHoles3x3[0][2].placeCard(c1, blue);
    Assert.assertEquals(ai.determineMove(), new ArrayList<>(Arrays.asList(2, 0, 0)));
    noHoles3x3[2][0].placeCard(c1, blue);
    Assert.assertEquals(ai.determineMove(), new ArrayList<>(Arrays.asList(2, 2, 0)));
  }

  /**
   * Tests if the AI correctly handles corner moves when some corners are holes.
   */
  @Test
  public void testCornersWithHoles() {
    Assert.assertEquals(ai.determineMove(), new ArrayList<>(Arrays.asList(0, 0, 0)));
    noHoles3x3[0][0] = new Cell(true);
    Assert.assertEquals(ai.determineMove(), new ArrayList<>(Arrays.asList(0, 2, 0)));
    noHoles3x3[0][2] = new Cell(true);
    Assert.assertEquals(ai.determineMove(), new ArrayList<>(Arrays.asList(2, 0, 0)));
    noHoles3x3[2][0] = new Cell(true);
    Assert.assertEquals(ai.determineMove(), new ArrayList<>(Arrays.asList(2, 2, 0)));
  }

  /**
   * Tests if the AI minimizes losses when all corners are occupied.
   */
  @Test
  public void testMinimizeAfterAllCorners() {
    noHoles3x3[0][0].placeCard(c1, blue);
    noHoles3x3[0][2].placeCard(c1, blue);
    noHoles3x3[2][0].placeCard(c1, blue);
    noHoles3x3[2][2].placeCard(c1, blue);
    Assert.assertEquals(ai.determineMove(), new ArrayList<>(Arrays.asList(0, 1, 0, 5)));
  }

  /**
   * Tests if the AI minimizes losses while handling holes on the board.
   */
  @Test
  public void testMinimizeWithHoles() {
    noHoles3x3[0][0].placeCard(c1, blue);
    noHoles3x3[0][2].placeCard(c1, blue);
    noHoles3x3[2][0].placeCard(c1, blue);
    noHoles3x3[2][2].placeCard(c1, blue);
    noHoles3x3[0][1] = new Cell(true);
    Assert.assertEquals(ai.determineMove(), new ArrayList<>(Arrays.asList(1, 0, 0, 5)));
  }

  /**
   * Tests the AI's greedy strategy when there are multiple red cards placed on the board.
   */
  @Test
  public void testGreedy() {
    noHoles3x3[0][0].placeCard(c1, red);
    noHoles3x3[0][1].placeCard(c1, red);
    noHoles3x3[1][0].placeCard(c1, red);
    model3x3.setAvailableSpaces(1);
    Assert.assertEquals(ai.determineMove(), List.of(0, 2, 0, 1));
  }

  /**
   * Tests the AI's greedy strategy when the red cards have the maximum value.
   */
  @Test
  public void testGreedyMaxCards() {
    noHoles3x3[0][0].placeCard(c5, red);
    noHoles3x3[0][1].placeCard(c5, red);
    noHoles3x3[1][0].placeCard(c5, red);
    model3x3.setAvailableSpaces(1);
    Assert.assertEquals(ai.determineMove(), List.of(0, 2, 0, 1));
  }

  /**
   * Tests the AI's behavior when there is only a single cell available on the board.
   */
  @Test
  public void testGreedySingleCell() {
    model3x3.setAvailableSpaces(1);
    Assert.assertEquals(ai.determineMove(), List.of(0, 0, 0, 1));
  }

  /**
   * Tests the AI's decision-making when encountering a board with holes and red cards.
   */
  @Test
  public void testGreedyHoleandCard() {
    model3x3.setAvailableSpaces(1);
    noHoles3x3[0][0].placeCard(c1, red);
    noHoles3x3[0][1] = new Cell(true);
    noHoles3x3[0][2] = new Cell(true);
    Assert.assertEquals(ai.determineMove(), List.of(1, 0, 0, 1));
  }

  /**
   * Tests the AI's minimax strategy for decision-making when there are two available spaces.
   */
  @Test
  public void testMinimax() {
    model3x3.setAvailableSpaces(2);
    Assert.assertEquals(ai.determineMove(), List.of(0, 0, 0));
  }

  /**
   * Tests the AI's minimax strategy when there is a card placed on the board and one is removed.
   */
  @Test
  public void testMinimaxWithCard() {
    model3x3.setAvailableSpaces(2);
    noHoles3x3[0][0] = c1;
    red.removeCard(4);
    Assert.assertEquals(ai.determineMove(), List.of(0, 0, 0));
  }
}
