import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import model.BoardPiece;
import model.Card;
import model.Color;
import model.TTB;
import view.TTBView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

/**
 * This tests the methods in the model TTB class.
 */
public class TTBTests {
  TTB<Card> threeXThreeTTB;
  char[][] threeXThreeCharGrid;
  ArrayList<String> threeXThreeCards;

  @Before
  public void setUp() throws FileNotFoundException {
    threeXThreeTTB = new TTB<>(new Random(2));
    threeXThreeCharGrid = new char[3][3];
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        threeXThreeCharGrid[i][j] = 'C';
      }
    }
    threeXThreeCharGrid[1][1] = 'X';
    threeXThreeCards = new ArrayList<>();
    Scanner scan =
            new Scanner(new FileReader(
                    "ConfigurationFiles/EnoughCardsForBothBoardsCardFile"));
    while (scan.hasNext()) {
      threeXThreeCards.add(scan.next());
    }
  }

  /**
   * This tests if startGame failed with too little cards.
   */
  @Test
  public void testStartGameFailsWithTooLittleCards() {
    assertThrows(IllegalArgumentException.class, () -> threeXThreeTTB.startGame(3, 3,
            threeXThreeCharGrid, new ArrayList<>(),
                    false));
  }

  /**
   * This tests if startGame fails when starting again.
   */
  @Test
  public void testStartGameFailsWithAnotherStart() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    assertThrows(IllegalStateException.class, () -> threeXThreeTTB.startGame(3, 3,
            threeXThreeCharGrid, threeXThreeCards,
                    false));
  }

  /**
   * This tests if startGame throws an exception when the game is already over.
   */
  @Test
  public void testStartGameFailsWithAnotherEnd() {
    threeXThreeTTB.startGame(0, 0, new char[0][0], threeXThreeCards, false);
    assertThrows(IllegalStateException.class, () -> threeXThreeTTB.startGame(0, 0,
            new char[0][0], threeXThreeCards,
                    false));
  }

  /**
   * This tests if getCard works correctly.
   */
  @Test
  public void testGetCard() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    threeXThreeTTB.placeCardTTB(0, 0, 0);
    assertEquals(threeXThreeTTB.getCardTTB(0, 0).getName(), "CorruptKing");
    assertEquals(threeXThreeTTB.getCardTTB(0, 0).getNorthVal(), 7);
    assertEquals(threeXThreeTTB.getCardTTB(0, 0).getSouthVal(), 3);
    assertEquals(threeXThreeTTB.getCardTTB(0, 0).getEastVal(), 1);
    assertEquals(threeXThreeTTB.getCardTTB(0, 0).getWestVal(), 9);
  }

  /**
   * Tests that the getCard method throws an IllegalArgumentException when called with invalid row
   * indices.
   */
  @Test
  public void testGetCardThrowsExceptions() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    assertThrows(IllegalArgumentException.class, () -> threeXThreeTTB.getCardTTB(-1, 0));
    assertThrows(IllegalArgumentException.class, () -> threeXThreeTTB.getCardTTB(4, 0));
  }

  /**
   * Verifies that the getRows method correctly returns the number of rows in the game board.
   */
  @Test
  public void testgetRows() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    assertEquals(threeXThreeTTB.getRows(), 3);
  }

  /**
   * Verifies that the getCols method correctly returns the number of columns in the game board.
   */
  @Test
  public void testgetCols() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    assertEquals(threeXThreeTTB.getCols(), 3);
  }

  /**
   * Checks the initial state of the game board to ensure that holes and null spaces are set
   * correctly.
   */
  @Test
  public void testgetBoard() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    BoardPiece[][] threeXThreeBoard = threeXThreeTTB.getBoard();
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        if (i == 1 && j == 1) {
          assertTrue(threeXThreeBoard[i][j].isHole());
        } else {
          assertNull(threeXThreeBoard[i][j]);
        }
      }
    }
  }

  /**
   * Verifies that players are initialized correctly with their respective colors.
   */
  @Test
  public void testGetPlayer() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    assertEquals(threeXThreeTTB.getPlayerRed().getColor(), Color.RED);
    assertEquals(threeXThreeTTB.getPlayerBlue().getColor(), Color.BLUE);
  }

  /**
   * Tests placing a card on the board and verifies that the board state updates correctly.
   */
  @Test
  public void testPlaceCard() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    TTBView<Card> view = new TTBView<>(threeXThreeTTB, new StringBuilder());
    threeXThreeTTB.placeCardTTB(0, 0, 0);
    assertEquals(view.toString(), "Player: Red\n"
            +
            "R  \n"
            +
            " _ \n"
            +
            "   \n"
            +
            "Hand:\n"
            +
            "AngryDragon 2 8 9 9\n"
            +
            "WindBird 7 2 3 5\n"
            +
            "HeroKnight 3 2 4 4\n");
  }

  /**
   * Tests placing multiple cards and switching turns, verifying that the board state updates
   * accordingly.
   */
  @Test
  public void testPlaceCardChange() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    TTBView<Card> view = new TTBView<>(threeXThreeTTB, new StringBuilder());
    threeXThreeTTB.placeCardTTB(0, 0, 0);
    threeXThreeTTB.placeCardTTB(1, 0, 1);
    threeXThreeTTB.nextTurn();
    threeXThreeTTB.placeCardTTB(2, 0, 0);
    assertEquals(view.toString(), "Player: Blue\n"
            +
            "B  \n"
            +
            "B_ \n"
            +
            "B  \n"
            +
            "Hand:\n"
            +
            "SkyWhale 6 4 2 7\n"
            +
            "ShadowLynx 5 9 6 3\n"
            +
            "IronGolem 4 7 5 8\n");
  }

  /**
   * Verifies that an IllegalArgumentException is thrown when attempting to place a card on an
   * occupied spot.
   */
  @Test
  public void testPlaceCardOnCard() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    TTBView<Card> view = new TTBView<>(threeXThreeTTB, new StringBuilder());
    threeXThreeTTB.placeCardTTB(0, 0, 0);
    assertThrows(IllegalArgumentException.class, () -> threeXThreeTTB.placeCardTTB(0, 0,
            1));
  }

  /**
   * Verifies that an IllegalArgumentException is thrown when attempting to place a card on a hole.
   */
  @Test
  public void testPlaceCardOnHole() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    TTBView<Card> view = new TTBView<>(threeXThreeTTB, new StringBuilder());
    assertThrows(IllegalArgumentException.class, () -> threeXThreeTTB.placeCardTTB(1, 1,
            0));
  }

  /**
   * Checks that an IllegalArgumentException is thrown when placing a card with an invalid hand
   * index.
   */
  @Test
  public void testPlaceCardInvalidHandIndex() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    TTBView<Card> view = new TTBView<>(threeXThreeTTB, new StringBuilder());
    assertThrows(IllegalArgumentException.class, () -> threeXThreeTTB.placeCardTTB(1, 1,
            100));
    assertThrows(IllegalArgumentException.class, () -> threeXThreeTTB.placeCardTTB(1, 1,
            -1));
  }

  /**
   * Ensures an IllegalArgumentException is thrown when trying to place a card with invalid row or
   * column indices.
   */
  @Test
  public void testPlaceCardInvalidAllIndex() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    TTBView<Card> view = new TTBView<>(threeXThreeTTB, new StringBuilder());
    assertThrows(IllegalArgumentException.class, () -> threeXThreeTTB.placeCardTTB(-1, 1,
            0));
    assertThrows(IllegalArgumentException.class, () -> threeXThreeTTB.placeCardTTB(100, 1,
            0));
  }

  /**
   * Tests that the nextTurn method correctly changes the current player.
   */
  @Test
  public void testNextTurn() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    threeXThreeTTB.nextTurn();
    assertEquals(threeXThreeTTB.getCurrPlayer().getColor(), Color.BLUE);
  }

  /**
   * Verifies that isGameOver returns true once the game board is fully occupied.
   */
  @Test
  public void testIsGameOver() {
    char[][] single = new char[1][1];
    single[0][0] = 'C';
    threeXThreeTTB.startGame(1, 1, new char[1][1], threeXThreeCards, false);
    threeXThreeTTB.placeCardTTB(0, 0, 0);
    assertTrue(threeXThreeTTB.isGameOver());
  }

  /**
   * Checks that getWinner correctly identifies the winning player when the game ends.
   */
  @Test
  public void testgetWinner() {
    char[][] single = new char[1][1];
    single[0][0] = 'C';
    threeXThreeTTB.startGame(1, 1, new char[1][1], threeXThreeCards, false);
    threeXThreeTTB.placeCardTTB(0, 0, 0);
    assertTrue(threeXThreeTTB.getWinner().getColor().equals(Color.RED));
  }

  /**
   * Tests the owner of a cell at given coordinates.
   */
  @Test
  public void testOwnerOfCell() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    threeXThreeTTB.placeCardTTB(0, 0, 0); // Player Red places a card
    assertEquals(Color.RED, threeXThreeTTB.getCardOwner(0, 0));
    assertNull(threeXThreeTTB.getCardOwner(2, 2)); // No card placed here yet
  }

  /**
   * Tests checking if a move is legal at specific coordinates.
   */
  @Test
  public void testLegalMoves() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    assertTrue(threeXThreeTTB.isLegalMove(0, 0)); // Legal spot
    assertFalse(threeXThreeTTB.isLegalMove(1, 1)); // Hole, not a legal spot
    threeXThreeTTB.placeCardTTB(0, 0, 0); // Place a card here
    assertFalse(threeXThreeTTB.isLegalMove(0, 0)); // Already occupied
  }

  /**
   * Tests how many cards a player can flip by playing a card at a given position.
   */
  @Test
  public void testCardFlipping() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    threeXThreeTTB.placeCardTTB(0, 0, 0); // Player Red places a card
    threeXThreeTTB.nextTurn();
    threeXThreeTTB.placeCardTTB(0, 1, 1); // Player Blue places a card adjacent
    assertEquals(1, threeXThreeTTB.countFlippedCards(0, 1)); // Expecting 1 card to flip
  }

  /**
   * Tests the player's score based on the cards they hold and control on the board.
   */
  @Test
  public void testPlayerScore() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    //player Red places a card
    threeXThreeTTB.placeCardTTB(0, 0, 0);
    //player Blue places a card
    threeXThreeTTB.placeCardTTB(1, 0, 1);
    //red has 1 card on the board
    assertEquals(1, threeXThreeTTB.getPlayerScore(threeXThreeTTB.getPlayerRed()));
    //blue has 1 card on the board
    assertEquals(1, threeXThreeTTB.getPlayerScore(threeXThreeTTB.getPlayerBlue()));
  }


}
