import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import controller.HumanPlayer;
import controller.PlayerController;
import controller.PlayerObserver;
import model.Cell;
import model.Color;
import model.MockModel;
import model.Player;
import view.GameFrame;

/**
 * This class contains JUnit tests for the PlayerController class.
 * These tests verify the functionality of PlayerController in managing player
 * interaction with the model and view.
 */
public class PlayerControllerTests {

  private PlayerController playerController;
  private GameFrame view;
  private MockModel model;
  private Player redPlayer;

  /**
   * This is the setup method.
   */
  @Before
  public void setUp() {
    Cell[][] cells = {{new Cell(true)}};
    redPlayer = new Player(Color.RED, List.of());
    Player bluePlayer = new Player(Color.BLUE, List.of());
    model = new MockModel(cells, redPlayer, bluePlayer);
    view = new GameFrame(List.of(), List.of(), cells, model, "hi");
    PlayerObserver playerObserver = new HumanPlayer(view, Color.RED);
    playerController = new PlayerController(playerObserver, model, view);
  }

  /**
   * Tests onPlayerTurn to ensure it updates the current player in the model.
   */
  @Test
  public void onPlayerTurnTest() {
    playerController.onPlayerTurn("");
    Assert.assertEquals(model.getCurrPlayer(), redPlayer);
  }

  /**
   * Tests onGameOver, running it opens the test.
   */
  @Test
  public void onGameOverTest() {
    playerController.onGameOver("Red");
    Assert.assertEquals(model.getCurrPlayer(), redPlayer);
  }

  /**
   * Tests getView to confirm it returns the reference to the GameFrame instance.
   */
  @Test
  public void getViewTest() {
    Assert.assertEquals(playerController.getView(), view);
  }
}