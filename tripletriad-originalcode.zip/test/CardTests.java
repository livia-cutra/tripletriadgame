import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

import model.Card;
import model.Color;
import model.Player;

import static org.junit.Assert.assertEquals;

/**
 * Tests the cards class.
 */
public class CardTests {
  private Card card;

  /**
   * Sets up the tests.
   */
  @Before
  public void setUp() {
    //initialize players
    Player redPlayer = new Player(Color.RED, Arrays.asList());
    Player bluePlayer = new Player(Color.BLUE, Arrays.asList());

    //initialize a card for testing
    card = new Card("TestCard",1, 2, 3, 4);
  }


  /**
   * Tests the Card constructor with owner, name, and specific values.
   * Verifies that the north, south, west, and east values are initialized correctly.
   */
  @Test
  public void testConstructorWithOwnerNameAndValues() {
    assertEquals(1, card.getNorthVal());
    assertEquals(2, card.getSouthVal());
    assertEquals(3, card.getWestVal());
    assertEquals(4, card.getEastVal());
  }

  /**
   * Tests Card initialization with a red player and specific values.
   * Verifies that the card's name, owner, and values are correctly set.
   */
  @Test
  public void testCardInitialization() {
    Player redPlayer = new Player(Color.RED, Arrays.asList());
    Card card = new Card("Dragon", 5, 3, 2, 4);
    assertEquals("Dragon", card.getName());
    assertEquals(5, card.getNorthVal());
    assertEquals(3, card.getSouthVal());
    assertEquals(2, card.getWestVal());
    assertEquals(4, card.getEastVal());
  }

  /**
   * Tests Card initialization with a blue player and assigned attack values.
   * Verifies that the card's name, owner, and values are correctly set.
   */
  @Test
  public void testCardWithDifferentOwnerAndValues() {
    Player bluePlayer = new Player(Color.BLUE, Arrays.asList());
    Card card = new Card("Phoenix", 9, 8, 7, 6);
    assertEquals("Phoenix", card.getName());
    assertEquals(9, card.getNorthVal());
    assertEquals(8, card.getSouthVal());
    assertEquals(7, card.getWestVal());
    assertEquals(6, card.getEastVal());
  }

  /**
   * Tests Card initialization with the same owner but different attack values.
   * Verifies that the card's name, owner, and values are correctly set.
   */
  @Test
  public void testCardWithSameOwnerButDifferentValues() {
    Player redPlayer = new Player(Color.RED, Arrays.asList());
    Card card = new Card("Knight", 1, 10, 9, 4);
    assertEquals("Knight", card.getName());
    assertEquals(1, card.getNorthVal());
    assertEquals(10, card.getSouthVal());
    assertEquals(9, card.getWestVal());
    assertEquals(4, card.getEastVal());
  }

}
