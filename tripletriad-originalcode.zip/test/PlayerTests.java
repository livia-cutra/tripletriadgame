import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import model.Card;
import model.Color;
import model.Player;

import static org.junit.Assert.assertEquals;

/**
 * These are the tests for the player.
 */
public class PlayerTests {
  private Player playerRed;
  private List<Card> hand;

  /**
   * Sets up the tests.
   */
  @Before
  public void setUp() {
    hand = new ArrayList<>();

    //add some test cards to the player's hand
    hand.add(new Card("Card1",1, 1, 1, 1));
    hand.add(new Card("Card2",10, 10, 10, 10));

    playerRed = new Player(Color.RED, hand); //create a player with a hand
  }

  /**
   * Tests selecting a card with a valid index.
   * Verifies that the selected card matches the expected card name.
   */
  @Test
  public void testSelectCardValidIndex() {
    Card selectedCard = playerRed.selectCard(0);
    assertEquals("Card1", selectedCard.getName(), "The selected card should be " +
            "Card1.");
  }

  /**
   * Verifies that getColorName returns the correct color name of the player.
   */
  @Test
  public void testGetColor() {
    assertEquals(playerRed.getColor(), Color.RED);
  }

  /**
   * Verifies that getHand returns the correct hand of cards for the player.
   */
  @Test
  public void testGetHand() {
    assertEquals(playerRed.getHand(), hand);
  }

  /**
   * Tests removing a card with a valid index.
   * Verifies that the removed card matches the expected card name.
   */
  @Test
  public void testRemoveCardValidIndex() {
    Card selectedCard = playerRed.removeCard(0);
    assertEquals("Card1", selectedCard.getName(),
            "The selected card should be Card1.");
  }

}

