import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import model.Card;
import model.TTB;
import view.TTBView;

import static org.junit.Assert.assertEquals;

/**
 * This class tests all the methods in TTBView.
 */
public class ViewTests {
  TTB<Card> threeXThreeTTB;
  char[][] threeXThreeCharGrid;
  ArrayList<String> threeXThreeCards;
  TTBView<Card> threeXThreeTTBView;

  @Before
  public void setUp() throws FileNotFoundException {
    threeXThreeTTB = new TTB<>(new Random(2));
    threeXThreeCharGrid = new char[3][3];
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        threeXThreeCharGrid[i][j] = 'C';
      }
    }
    threeXThreeCharGrid[1][1] = 'X';
    threeXThreeCards = new ArrayList<>();
    Scanner scan =
            new Scanner(new FileReader(
            "ConfigurationFiles/EnoughCardsForBothBoardsCardFile"));
    while (scan.hasNext()) {
      threeXThreeCards.add(scan.next());
    }
    threeXThreeTTBView = new TTBView<>(threeXThreeTTB, new StringBuilder());
  }

  /**
   * This tests if toString() works.
   */
  @Test
  public void testToString() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    assertEquals(threeXThreeTTBView.toString(), "Player: Red\n"
            +
            "   \n"
            +
            " _ \n"
            +
            "   \n"
            +
            "Hand:\n"
            +
            "CorruptKing 7 3 1 9\n"
            +
            "AngryDragon 2 8 9 9\n"
            +
            "WindBird 7 2 3 5\n"
            +
            "HeroKnight 3 2 4 4\n");
  }

  /**
   * This tests if toString() works after placing a card.
   */
  @Test
  public void testToStringPlaceCard() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    threeXThreeTTB.placeCardTTB(0, 0, 0);
    assertEquals(threeXThreeTTBView.toString(), "Player: Red\n"
            +
            "R  \n"
            +
            " _ \n"
            +
            "   \n"
            +
            "Hand:\n"
            +
            "AngryDragon 2 8 9 9\n"
            +
            "WindBird 7 2 3 5\n"
            +
            "HeroKnight 3 2 4 4\n");
  }

  /**
   * This tests if toString() works after a nextTurn().
   */
  @Test
  public void testToStringNextTurn() {
    threeXThreeTTB.startGame(3, 3, threeXThreeCharGrid, threeXThreeCards, false);
    threeXThreeTTB.nextTurn();
    assertEquals(threeXThreeTTBView.toString(), "Player: Blue\n"
            +
            "   \n"
            +
            " _ \n"
            +
            "   \n"
            +
            "Hand:\n"
            +
            "WorldDragon 8 3 7 5\n"
            +
            "SkyWhale 6 4 2 7\n"
            +
            "ShadowLynx 5 9 6 3\n"
            +
            "IronGolem 4 7 5 8\n");
  }

  /**
   * This tests if toString() works and successfully prints a winner after a win.
   */
  @Test
  public void testToStringGameOver() {
    char[][] single = new char[1][1];
    single[0][0] = 'C';
    threeXThreeTTB.startGame(1, 1, new char[1][1], threeXThreeCards, false);
    threeXThreeTTB.placeCardTTB(0, 0, 0);
    assertEquals(threeXThreeTTBView.toString(), "Player: Red\n" +
            "R\n" +
            "Hand:\n" +
            "Winner: Blue\n");
  }
}
