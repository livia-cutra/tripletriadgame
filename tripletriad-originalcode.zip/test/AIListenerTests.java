import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import controller.AIListener;
import controller.HumanPlayer;
import controller.PlayerObserver;
import model.Cell;
import model.Color;
import model.MockModel;
import model.Player;
import view.GameFrame;

/**
 * This class contains JUnit tests for the AIListener class.
 * These tests verify the functionality of the AIListener implementation.
 */
public class AIListenerTests {

  private AIListener aiListener;
  private GameFrame view;
  private MockModel model;
  private Player redPlayer;

  /**
   * This is the setup method.
   */
  @Before
  public void setUp() {
    Cell[][] cells = {{new Cell(true)}};
    redPlayer = new Player(Color.RED, List.of());
    Player bluePlayer = new Player(Color.BLUE, List.of());
    model = new MockModel(cells, redPlayer, bluePlayer);
    view = new GameFrame(List.of(), List.of(), cells, model, "hi");
    PlayerObserver playerObserver = new HumanPlayer(view, Color.RED);
    aiListener = new AIListener(playerObserver, model, view, "strategy_1");
  }

  /**
   * This test verifies that the onPlayerTurn method of AIListener
   * correctly sets the current player in the model to the red player.
   */
  @Test
  public void onPlayerTurnTest() {
    aiListener.onPlayerTurn("");
    Assert.assertEquals(model.getCurrPlayer(), redPlayer);
  }

  /**
   * This test verifies the behavior of the onGameOver method of AIListener.
   */
  @Test
  public void onGameOverTest() {
    aiListener.onGameOver("Red");
    Assert.assertEquals(model.getCurrPlayer(), redPlayer);
  }

  /**
   * This test verifies that the getView method of AIListener
   * correctly returns the reference to the GameFrame view.
   */
  @Test
  public void getViewTest() {
    Assert.assertEquals(aiListener.getView(), view);
  }
}
