import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import controller.HumanPlayer;
import model.Cell;
import model.Color;
import model.MockModel;
import model.Player;
import view.GameFrame;

/**
 * This class contains JUnit tests for the HumanPlayer class.
 * These tests verify the functionality of the HumanPlayer implementation.
 */
public class HumanPlayerTests {


  private GameFrame view;
  private HumanPlayer playerObserver;

  /**
   * This method sets up the test environment before each test case.
   * It creates mock objects for the model, players, and cells,
   * then initializes the GameFrame and HumanPlayer objects.
   */
  @Before
  public void setUp() {
    Cell[][] cells = {{new Cell(true)}};
    Player redPlayer = new Player(Color.RED, List.of());
    Player bluePlayer = new Player(Color.BLUE, List.of());
    MockModel model = new MockModel(cells, redPlayer, bluePlayer);
    view = new GameFrame(List.of(), List.of(), cells, model, "hi");
    playerObserver = new HumanPlayer(view, Color.RED);
  }

  /**
   * This test verifies that the startTurn method of HumanPlayer
   * enables the GameFrame view.
   */
  @Test
  public void testStartTurn() {
    playerObserver.startTurn();
    Assert.assertTrue(view.isEnabled());
  }

  /**
   * This test verifies that the endTurn method of HumanPlayer
   * does not disable the GameFrame view (might be unexpected behavior).
   */
  @Test
  public void testEndTurn() {
    playerObserver.endTurn();
    Assert.assertTrue(view.isEnabled()); // This behavior might need review
  }

  /**
   * This test verifies that the getColor method of HumanPlayer
   * correctly returns the player's color (RED in this case).
   */
  @Test
  public void testGetColor() {
    Assert.assertEquals(Color.RED, playerObserver.getColor());
  }
}
