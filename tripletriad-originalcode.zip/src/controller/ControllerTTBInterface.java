package controller;

import java.util.List;

/**
 * Interface for ControllerTTB, defining the main methods for managing
 * game flow and interactions between model, view, and AI.
 */
public interface ControllerTTBInterface {


  /**
   * Starts the game with the specified parameters, initializing the game board, player hands, and
   * views.
   *
   * @param rows     the number of rows for the game board
   * @param cols     the number of columns for the game board
   * @param readGrid the initial configuration of the board
   * @param cards    a list of card names to be used in the game
   * @param shuffle  whether to shuffle the deck of cards
   */
  void startGame(int rows, int cols, char[][] readGrid, List<String> cards, boolean shuffle);

}
