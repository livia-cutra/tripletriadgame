package controller;

import view.GameFrame;

/**
 * Represents a listener interface for controllers to implement.
 * This interface provides methods for handling notifications from the model,
 * such as when it is a player's turn or when the game ends.
 * Controllers implementing this interface can respond to these events and
 * update the view or game state accordingly.
 */
public interface ModelListener {

  /**
   * Notifies the listener when it is a specific player's turn.
   *
   * @param playerName the name of the player whose turn it is
   */
  void onPlayerTurn(String playerName);

  /**
   * Notifies the listener when the game ends.
   *
   * @param winnerName the name of the winning player, or {@code null} if there is no winner
   */
  void onGameOver(String winnerName);

  /**
   * Retrieves the view associated with the listener.
   * This allows the controller to access and update the graphical user interface (GUI) as needed.
   *
   * @return the {@link GameFrame} instance associated with this listener
   */
  GameFrame getView();
}

