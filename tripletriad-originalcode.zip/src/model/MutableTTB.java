package model;

import java.util.List;

import controller.ModelListener;

/**
 * Represents a mutable Triple Triad game model.
 * This interface extends ReadOnlyTTB, adding methods that modify the game state.
 * It provides operations to manipulate the game, such as starting the game,
 * placing cards, and advancing turns.
 */
public interface MutableTTB extends ReadOnlyTTB {

  /**
   * Starts the game by initializing the board and dealing cards to players.
   *
   * @param rows     the number of rows in the board
   * @param cols     the number of columns in the board
   * @param readGrid a 2D array representing the initial board state
   * @param cards    a list of card descriptions
   * @param shuffle  whether to shuffle the cards before dealing
   * @throws IllegalArgumentException if there are not enough cards for the available spaces
   */
  void startGame(int rows, int cols, char[][] readGrid, List<String> cards, boolean shuffle);

  /**
   * Places a card on the game board at the specified column and row.
   *
   * @param col         the column where the card is to be placed
   * @param row         the row where the card is to be placed
   * @param handIdx     the Idx of  the Card object to be placed on the board from the hand
   * @throws IllegalArgumentException if the position is out of bounds, is a hole,
   *                                  or is occupied by another card
   */
  void placeCardTTB(int row, int col, int handIdx);

  /**
   * Proceeds to the next turn, switching the current player.
   *
   * @throws IllegalStateException if the game is over or has not started.
   */
  void nextTurn();

  /**
   * Gets the current player of the game, whichever player has their turn right now.
   *
   * @return the player that has their turn currently
   */
  Player getCurrPlayer();

  //idk if this will fix it

  // Notify listeners when it's a player's turn
  void notifyPlayerTurn(String playerName);

  // Notify listeners about game overz
  void notifyGameOver(String winnerName);

  // Add a listener for model events
  void addModelListener(ModelListener listener);
}
