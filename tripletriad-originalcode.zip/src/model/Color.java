package model;

/**
 * The color of the card representing the player, which could only be red or blue.
 */
public enum Color {
  RED, BLUE;

  /**
   * This converts Color to a string.
   * @return a Color as a string.
   */
  public String toString() {
    if (this == Color.RED) {
      return "Red";
    }
    return "Blue";
  }
}


