package model;

import controller.ModelListener;

/**
 * Interface defining the features for notifying and managing model events. Implementations of this
 * interface are responsible for handling the communication of significant game events, such as
 * player turns and game over states, to registered listeners.
 */
public interface ModelFeatures {

  /**
   * Notifies all registered listeners when it is a player's turn.
   *
   * @param playerName the name of the player whose turn it is
   */
  void notifyPlayerTurn(String playerName);

  /**
   * Notifies all registered listeners that the game has ended and provides the winner's name.
   *
   * @param winnerName the name of the player who won the game, or null if it's a draw
   */
  void notifyGameOver(String winnerName);

  /**
   * Adds a listener to the model for receiving event notifications.
   *
   * @param listener the {@link ModelListener} to be registered
   */
  void addModelListener(ModelListener listener);
}