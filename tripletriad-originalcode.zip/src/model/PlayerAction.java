package model;

/**
 * An interface that defines the actions a player can perform.
 */
public interface PlayerAction {

  /**
   * Selects a card from the player's hand based on the given index.
   *
   * @param indexAtHand the index of the card to select
   * @return the selected Card object
   * @throws IndexOutOfBoundsException if the index is invalid
   */
  Card selectCard(int indexAtHand);

}
