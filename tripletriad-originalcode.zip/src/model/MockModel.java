package model;

import java.util.List;

import controller.ModelListener;

/**
 * A MockModel of TripleTrios that help with testing.
 */
public class MockModel implements MutableTTB {

  Cell[][] b;
  Player red;
  Player blue;
  int availableSpaces;

  /**
   * Constructor to instantiate mockmodel.
   *
   * @param b    represents an array of cells (board)
   * @param red  represents red player
   * @param blue represents blue player
   */
  public MockModel(Cell[][] b, Player red, Player blue) {
    this.b = b;
    this.red = red;
    this.blue = blue;
  }

  @Override
  public int getRows() {
    return b.length;
  }

  @Override
  public int getCols() {
    return b[0].length;
  }

  @Override
  public Cell[][] getBoard() {
    return b;
  }

  @Override
  public Player getPlayerRed() {
    return red;
  }

  @Override
  public Player getPlayerBlue() {
    return blue;
  }

  @Override
  public Card getCardTTB(int row, int col) {
    return b[row][col].getCard();
  }

  @Override
  public boolean isGameOver() {
    return false;
  }

  @Override
  public void startGame(int rows, int cols, char[][] readGrid, List<String> cards,
                        boolean shuffle) {
    //This does nothing for mock.
  }

  @Override
  public void placeCardTTB(int row, int col, int handIdx) {

  }

  @Override
  public void nextTurn() {
    //This does nothing for mock.
  }

  @Override
  public Player getCurrPlayer() {
    return red;
  }

  @Override
  public void notifyPlayerTurn(String playerName) {
    //This does nothing for mock.
  }

  @Override
  public void notifyGameOver(String winnerName) {
    //This does nothing for mock.
  }

  @Override
  public void addModelListener(ModelListener listener) {

  }

  @Override
  public int getAvailableSpaces() {
    return availableSpaces;
  }

  public void setAvailableSpaces(int availableSpaces) {
    this.availableSpaces = availableSpaces;
  }

  @Override
  public String getPlayerString() {
    return "";
  }

  @Override
  public Player getWinner() {
    return null;
  }

  @Override
  public Color getCardOwner(int row, int col) {
    return null;
  }

  @Override
  public boolean isLegalMove(int row, int col) {
    return true;
  }

  @Override
  public int getPlayerScore(Player player) {
    return 0;
  }
}
