package model;

/**
 * Represents a cell on the game board that may contain a card, be assigned to an owner, or be
 * marked as a hole. Cells can hold cards, have ownership transferred, and indicate their state
 * with different symbols.
 */
public class Cell implements BoardPiece {
  private Card card;
  private Player owner;
  private final boolean isHole;

  /**
   * Constructs an empty cell without a hole.
   */
  public Cell() {
    this.card = null;
    this.owner = null;
    this.isHole = false;
  }

  /**
   * Constructs a cell with the specified hole status.
   *
   * @param isHole true if the cell is a hole, false otherwise
   */
  public Cell(boolean isHole) {
    this.card = null;
    this.owner = null;
    this.isHole = isHole;
  }

  /**
   * Constructs a new cell as a copy of the specified cell.
   * If the cell contains a card, the owner is also copied.
   *
   * @param c the cell to copy
   */
  public Cell(Cell c) {
    this.card = c.getCard();
    if (c.isCard()) {
      this.owner = new Player(c.getOwnerColor(), null);
    } else {
      this.owner = null;
    }
    this.isHole = c.isHole;
  }

  /**
   * Places a card in the cell, assigning ownership to the specified player.
   *
   * @param card  the card to place in the cell
   * @param owner the player who owns the card
   * @throws IllegalStateException if the cell is a hole
   */
  public void placeCard(Card card, Player owner) {
    if (isHole) {
      throw new IllegalStateException("cannot place a card in a hole.");
    }
    this.card = card;
    this.owner = owner;
  }

  /**
   * Returns whether the cell is a hole.
   *
   * @return true if the cell is a hole, false otherwise
   */
  @Override
  public boolean isHole() {
    return isHole;
  }

  /**
   * Returns whether the cell contains a card.
   *
   * @return true if the cell contains a card, false otherwise
   */
  @Override
  public boolean isCard() {
    return this.card != null;
  }

  /**
   * Returns the card contained in the cell, if any.
   *
   * @return the card in the cell, or null if the cell is empty
   */
  public Card getCard() {
    return this.card;
  }

  /**
   * Sets a card in the cell without assigning ownership.
   *
   * @param card the card to set in the cell
   */
  public void setCard(Card card) {
    this.card = card;
  }

  /**
   * Returns the color of the player who owns the card in the cell.
   *
   * @return the color of the card owner
   * @throws IllegalStateException if no owner is set for the cell
   */
  public Color getOwnerColor() {
    if (this.owner == null) {
      throw new IllegalStateException("No owner is set for this cell.");
    }
    return this.owner.getColor();
  }

  /**
   * Switches the owner of the card to the specified player.
   *
   * @param owner the new owner of the card
   */
  public void switchOwner(Player owner) {
    this.owner = owner;
  }

  /**
   * Checks if the current cell contains a card owned by the opponent.
   * A cell is considered to have an opponent's card if it is not empty (i.e., not null)
   * and the card's owner color is different from the current player's color.
   *
   * @param currentPlayer the player whose opponent is being checked
   * @return true if the cell contains a card that belongs to the opponent; false otherwise
   */
  public boolean hasOpponentCard(Player currentPlayer) {
    return card != null && !card.getOwnerColor().equals(currentPlayer.getColor());
  }

  /**
   * Returns a string representation of the cell's state.
   * "_" indicates a hole, "R" represents a cell owned by a red player, "B" by a blue player,
   * and " " if unowned.
   *
   * @return a string symbolizing the cell's state
   */
  @Override
  public String toString() {
    if (isHole) {
      return "_";
    }
    if (this.owner == null) {
      return " ";
    } else {
      if (this.owner.getColor().equals(Color.RED)) {
        return "R";
      } else {
        return "B";
      }
    }
  }

}
