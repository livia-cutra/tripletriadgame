package model;

/**
 * Represents a read-only view of the Triple Triad game board.
 * The read-only interface provides observation methods to view
 * the current state of the game without allowing any modifications.
 * This interface is extended by the mutable interface TTB.
 */
public interface ReadOnlyTTB {
  /**
   * Retrieves the number of rows in the board.
   *
   * @return the number of rows in the board
   */
  int getRows();

  /**
   * Retrieves the number of columns in the board.
   *
   * @return the number of columns in the board
   */
  int getCols();

  /**
   * Retrieves the current state of the board as a 2D array of BoardPiece objects.
   *
   * @return a 2D array representing the current state of the board
   */
  Cell[][] getBoard();

  /**
   * Retrieves the player representing the red team.
   *
   * @return the Player object representing the red player
   */
  Player getPlayerRed();

  /**
   * Retrieves the player representing the blue team.
   *
   * @return the Player object representing the blue player
   */
  Player getPlayerBlue();

  /**
   * Retrieves the card at the specified row and column.
   *
   * @param row the row of the card
   * @param col the column of the card
   * @return the Card object at the specified position, or null if there is no card
   */
  Card getCardTTB(int row, int col);

  /**
   * Checks if the game is over or not.
   *
   * @return whether the game is over
   */
  boolean isGameOver();

  /**
   * Gets the current player of the game, whichever player has their turn right now.
   *
   * @return the player that has their turn currently
   */
  Player getCurrPlayer();

  /**
   * Retrieves the number of available spaces in the current context.
   *
   * @return the number of available spaces as an integer
   */
  int getAvailableSpaces();

  /**
   * Gets the current player of the game and returns its name as a string value,
   * whichever player has their turn right now.
   *
   * @return the name of the player that has their turn currently
   */
  String getPlayerString();

  /**
   * Gets the winner of the game.
   *
   * @return the player that won, if it is a draw, returns null
   */
  Player getWinner();

  /**
   * Returns the color of the player who owns the card at the given coordinates.
   *
   * @return the color of the card owner
   * @throws IllegalStateException if no owner is set for the cell
   */
  Color getCardOwner(int row, int col);

  /**
   * Checks whether a move is legal based on the state of a specific cell on the board.
   * A move is legal if the cell is not a hole and does not contain a card.
   *
   * @param row The row index of the cell to check.
   * @param col The column index of the cell to check.
   * @return true if the move is legal (the cell is not a hole or a card), false otherwise.
   */
  boolean isLegalMove(int row, int col);

  /**
   * Calculates the current score of a player based on the number of cards in their hand
   * and the number of cards they own on the board. The score is the total number of cards the
   * player has in their hand, plus the number of cards on the board that are owned by the player
   * (cards whose owner color matches the player's color).
   *
   * @param player The player whose score is to be calculated.
   * @return The total score of the player, which is the sum of the player's hand size and owned
   *     cards on the board.
   */
  int getPlayerScore(Player player);
}
