package model;

import java.util.List;

/**
 * A class that represents a player in the game, either RED or BLUE.
 */
public class Player implements PlayerAction {
  private Color color;
  private List<Card> hand;

  /**
   * Constructs a Player with a specified color and hand of cards.
   *
   * @param color the color of the player (RED or BLUE)
   * @param hand the initial list of cards in the player's hand
   */
  public Player(Color color, List<Card> hand) {
    this.color = color;
    this.hand = hand;

  }

  /**
   * Retrieves the color of the player.
   *
   * @return the color of the player (RED or BLUE)
   */
  public Color getColor() {
    return color;
  }

  /**
   * Retrieves the list of cards in the player's hand.
   *
   * @return the list of cards currently held by the player
   */
  public List<Card> getHand() {
    return hand;
  }

  /**
   * This removes a card from the hand of the player.
   *
   * @param cardIdx the index of the card to be removed.
   * @return the removed card.
   */
  public Card removeCard(int cardIdx) {
    if (cardIdx < 0 || cardIdx >= hand.size()) {
      throw new IllegalArgumentException("Invalid card index: " + cardIdx);
    }

    Card returnable = hand.get(cardIdx);
    hand.remove(cardIdx);
    return returnable;
  }

  /**
   * Selects a card from the player's hand based on the given index.
   *
   * @param indexAtHand the index of the card to select
   * @return the selected Card object
   * @throws IndexOutOfBoundsException if the index is invalid
   */
  @Override
  public Card selectCard(int indexAtHand) {
    //check if the index is within bounds of the player's hand
    if (indexAtHand < 0 || indexAtHand >= hand.size()) {
      throw new IllegalArgumentException("Invalid card index: " + indexAtHand);
    }

    //return the selected card
    return hand.get(indexAtHand);
  }
}
