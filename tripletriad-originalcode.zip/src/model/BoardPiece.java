package model;

/**
 * Represents a BoardPiece with potential mutation capabilities.
 */
public interface BoardPiece {

  /**
   * Determines if this piece is a hole.
   *
   * @return true if this piece is a hole, false otherwise
   */
  boolean isHole();

  /**
   * Determines if this piece contains a card.
   *
   * @return true if this piece contains a card, false otherwise
   */
  boolean isCard();

  /**
   * Gets the card contained in this piece, if any.
   *
   * @return the card in this piece, or null if empty
   */
  Card getCard();

  /**
   * Provides a string representation of this piece.
   *
   * @return a string symbolizing the piece's state
   */
  String toString();
}

