import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import model.Card;
import model.TTB;
import view.TTBView;

/**
 * This class reads the configuration files for a game of Text-based Treasure Hunt (TTB)
 * and initializes the game state.
 */
public class TTBReader {
  /**
   * Prompts the user for the paths of the board and card files.
   * Reads the board configuration and card list from the provided files.
   *
   * @param args not used
   */
  public static void main(String[] args) {

    Scanner sc = new Scanner(System.in);
    System.out.println("input the directory path name of the board file: ");
    String path = sc.nextLine();
    FileReader boardFile;
    while (true) {
      try {
        boardFile = new FileReader(path);
        break;
      } catch (FileNotFoundException e) {
        System.out.println("File not found, please try again");
        path = sc.nextLine();
      }
    }
    System.out.println("input the directory path name of the card file: ");
    path = sc.nextLine();
    FileReader cardFile;
    while (true) {
      try {
        cardFile = new FileReader(path);
        break;
      } catch (FileNotFoundException e) {
        System.out.println("File not found, please try again");
        path = sc.nextLine();
      }
    }

    Scanner scan = new Scanner(boardFile); // this some grid configuration file
    int r = scan.nextInt();
    int c = scan.nextInt();
    char[][] boardArray = new char[r][c];
    for (int i = 0; i < r; i++) {
      String str = scan.next();
      for (int j = 0; j < c; j++) {
        boardArray[i][j] = str.charAt(j);
      }
    }

    scan = new Scanner(cardFile);
    ArrayList<String> cardList = new ArrayList<String>();
    while (scan.hasNext()) {
      cardList.add(scan.next());
    }
    Random seed = new Random(2);
    TTB<Card> bd = new TTB<Card>(seed);
    bd.startGame(r, c, boardArray, cardList, false);
    TTBView<Card> ttbView = new TTBView(bd, new StringBuilder());
    System.out.println(ttbView);

  }
}
