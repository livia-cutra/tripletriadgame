package view;

import java.awt.Color;
import java.awt.BorderLayout;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import model.Card;
import model.Cell;
import model.Player;
import model.ReadOnlyTTB;

/**
 * The GameFrame class represents the main game window for the Triple Trios game.
 * It sets up the graphical user interface (GUI), displaying the game board,
 * the player hands, and the current player. It allows interaction with the game
 * via the BoardPanel and PlayerPanels, and provides methods to interact with
 * the game state.
 */
public class GameFrame extends JFrame implements GameView {
  //the read-only model representing the game state.
  private ReadOnlyTTB game;
  //panel for displaying the game board.
  private BoardPanel boardPanel;
  //panel for the red player's hand.
  private PlayerPanel redPlayerPanel;
  //panel for the blue player's hand.
  private PlayerPanel bluePlayerPanel;
  private String playerTitle;


  /**
   * Constructor for the GameFrame class. Sets up the window, panels, and game
   * elements like player hands and the game board.
   *
   * @param redHand  A list of cards representing the red player's hand.
   * @param blueHand A list of cards representing the blue player's hand.
   * @param board    A 2D array of cells representing the game board.
   * @param game     The read-only game model.
   * @param playerTitle The title representing the player (e.g., "Red Player").
   */
  public GameFrame(List<Card> redHand, List<Card> blueHand, Cell[][] board, ReadOnlyTTB game, String playerTitle) {
    this.game = game;
    setTitle("Triple Trios Game");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(800, 600);
    setLayout(new BorderLayout());

    this.playerTitle = playerTitle;

    //create the top panel and set up the current player label
//    this.topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); //FlowLayout centers the label
//    JLabel currentPlayerLabel = new JLabel("Current Player: " + this.game.getCurrPlayer().getColor());
//    topPanel.add(currentPlayerLabel);  //add the label to the top panel
//    add(topPanel, BorderLayout.NORTH);  //add the top panel to the frame

    //sets the title for player view
    setTitle(playerTitle);


    //left Panel for Red Player
    this.redPlayerPanel = new PlayerPanel(redHand, Color.PINK, "RED");
    add(redPlayerPanel, BorderLayout.WEST);

    //center Panel for the Game Board
    this.boardPanel = new BoardPanel(board);
    add(boardPanel, BorderLayout.CENTER);

    //right Panel for Blue Player
    this.bluePlayerPanel = new PlayerPanel(blueHand, new Color(173, 216, 240),
            "BLUE");
    add(bluePlayerPanel, BorderLayout.EAST);

    this.repaint();


    setVisible(true);
  }

  /**
   * Sets the features interface for handling player actions.
   *
   * @param features the Features interface to handle user interactions
   */
  public void setFeatures(Features features) {
    boardPanel.setFeatures(features);
    redPlayerPanel.setFeatures(features);
    bluePlayerPanel.setFeatures(features);
  }

  /**
   * Displays a message to the player in a dialog box.
   *
   * @param message the message to display
   */
  public void showMessage(String message) {
    JOptionPane.showMessageDialog(this, message);
  }

  /**
   * Displays an error message to the player in a dialog box.
   *
   * @param error the error message to display
   */
  public void showError(String error) {
    boardPanel.deselectRowCol();
    boardPanel.repaint();
  }

  /**
   * Updates the game board with the latest state.
   *
   * @param board the updated board state
   */
  public void updateBoard(Cell[][] board) {
    // Update the board in the BoardPanel
    boardPanel.updateBoard(board);

    // Refresh the UI to reflect the new state
    repaintAll();
  }

  /**
   * Enables or disables user interactions in the UI.
   *
   * @param enable {@code true} to enable interactions, {@code false} to disable
   */
  public void enableInteractions(boolean enable) {
    // enable or disable the board panel
    boardPanel.setEnabled(enable);
    // enable or disable player panels
    if (playerTitle.contains("Red")) {
      redPlayerPanel.setEnabled(enable);
      bluePlayerPanel.setEnabled(false);
    }
    if (playerTitle.contains("Blue")) {
      bluePlayerPanel.setEnabled(enable);
      redPlayerPanel.setEnabled(false);
    }

    // optionally, add specific logic for enabling/disabling buttons or other interactions
    if (!enable) {
      boardPanel.deselectRowCol(); // Clear any previous selections if disabling
      redPlayerPanel.deselectCard(); // Clear selected card if disabling
      bluePlayerPanel.deselectCard();
    }

    // refresh the UI
    repaintAll();
  }

  /**
   * Returns the current game model.
   *
   * @return the read-only game model.
   */
  public ReadOnlyTTB getGame() {
    return game;
  }

  /**
   * Gets the coordinates of the currently selected cell in the board.
   *
   * @return A list containing the row and column indices of the selected cell,
   * or null if no cell is selected.
   */
  public List<Integer> getSelectedRowCol() {
    List<Integer> arr = boardPanel.getSelectedRowCol();
    if (arr.get(0) == -1) {
      return null;
    } else if (arr.get(1) == -1) {
      return null;
    }
    return arr;
  }

  /**
   * Gets the card that is currently selected by the player.
   *
   * @param currPlayer The current player who is selecting a card.
   * @return The selected card from the player's hand.
   */
  public Card getSelectedCard(Player currPlayer) {
    if (currPlayer.getColor().equals(model.Color.RED)) {
      return redPlayerPanel.getSelectedCard();
    } else {
      return bluePlayerPanel.getSelectedCard();
    }
  }

  /**
   * Gets the index of the currently selected card from the player's hand.
   *
   * @param currPlayer The current player.
   * @return The index of the selected card in the player's hand.
   */
  public int getSelectedCardIndex(Player currPlayer) {
    if (currPlayer.getColor().equals(model.Color.RED)) {
      return redPlayerPanel.getSelectedCardIndex();
    } else {
      return bluePlayerPanel.getSelectedCardIndex();
    }
  }

  /**
   * Deselects the currently selected cell in the game board.
   */
  public void deSelectRowCol() {
    boardPanel.deselectRowCol();
  }

  /**
   * Repaints all components of the game frame, including the game board and player panels.
   */
  public void repaintAll() {
    boardPanel.repaint();
    redPlayerPanel.repaint();
    bluePlayerPanel.repaint();
  }

  /**
   * Updates the game state, including the player hands and board.
   *
   * @param redHand  the red player's updated hand
   * @param blueHand the blue player's updated hand
   * @param board    the updated board state
   */
  public void updateGameState(List<Card> redHand, List<Card> blueHand, Cell[][] board) {
    this.redPlayerPanel.updateHand(redHand);
    this.bluePlayerPanel.updateHand(blueHand);
    this.boardPanel.updateBoard(board);
    this.repaintAll();
  }

}


