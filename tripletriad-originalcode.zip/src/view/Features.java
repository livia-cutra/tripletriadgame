package view;

/**
 * Represents the high-level actions a player can perform in the game.
 * The Features interface is implemented by the controller and utilized
 * by the view to handle player interactions such as selecting cards and cells.
 * These interactions trigger corresponding game logic in the controller.
 */
public interface Features {

  /**
   * Invoked when a player selects a card.
   *
   * @param cardIndex the index of the card being selected
   * @param player    the name or identifier of the player selecting the card
   */
  void selectCard(int cardIndex, String player);

  /**
   * Invoked when a player selects a cell on the game board.
   *
   * @param row the row index of the selected cell
   * @param col the column index of the selected cell
   */
  void selectCell(int row, int col);
}
