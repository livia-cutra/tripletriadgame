package view;

import java.awt.Graphics;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

import model.Cell;

/**
 * A JPanel that represents the game board, displaying cells and handling user interactions such as
 * selecting a cell.
 *
 * <p>This panel dynamically renders a grid based on the board array, highlighting the selected cell
 * and displaying different types of cells (holes, cards, or empty). It allows users to interact
 * with the grid by clicking on cells, selecting or deselecting them.
 */
public class BoardPanel extends JPanel {
  //the board
  private Cell[][] board;
  //the index of the selected row in the hand.
  private int selectedRow = -1;
  //the index of the selected col in the hand.
  private int selectedCol = -1;
  private Appendable ap;
  private Features features;

  /**
   * Constructs a BoardPanel with the specified board layout.
   *
   * @param board A 2D array of {@link model.Cell} representing the board's current state.
   */
  public BoardPanel(Cell[][] board) {
    this.board = board;
    this.ap = ap;

    addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(MouseEvent e) {
        try {
          handleMouseClick(e);
        } catch (IOException ex) {
          throw new RuntimeException(ex);
        }
      }
    });

  }

  public void setFeatures(Features features) {
    this.features = features;
  }

  /**
   * Paints the component, rendering the grid of cells.
   *
   * <p>Each cell is drawn with a specific color depending on its state. The selected cell is
   * highlighted with a gray border, and cells are rendered based on their type (hole/ card/ empty).
   *
   * @param g The Graphics object used for rendering the board.
   */
  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g;

    int rows = board.length;
    int cols = board[0].length;

    //calculate dynamic cell dimensions based on panel size
    int cellWidth = getWidth() / cols;
    int cellHeight = getHeight() / rows;

    //iterate over each cell in the board array
    for (int row = 0; row < rows; row++) {
      for (int col = 0; col < cols; col++) {
        int x = col * cellWidth;
        int y = row * cellHeight;
        //highlight selected cell
        if (row == selectedRow && col == selectedCol) {
          g2.setColor(Color.GRAY);
          g2.setStroke(new BasicStroke(3));  //thick border for highlighting
          g2.drawRect(x, y, cellWidth, cellHeight);
        } else {
          g2.setStroke(new BasicStroke(1));  //regular border for unselected cards
          g2.setColor(Color.BLACK);  //border color for unselected card
          g2.drawRect(x, y, cellWidth, cellHeight);  //draw unselected card's border
        }
        drawCell(g2, board[row][col], x, y, cellWidth, cellHeight);

      }

    }
  }

  /**
   * Handles mouse clicks on the board, updating the selected cell.
   *
   * <p>If the clicked cell is already selected, it will be deselected; otherwise, the new cell will
   * be selected.
   *
   * @param e The MouseEvent triggered by a click on the board.
   */
  private void handleMouseClick(MouseEvent e) throws IOException {
    if (isEnabled()) {
      int cellWidth = getWidth() / board[0].length;
      int cellHeight = getHeight() / board.length;

      int col = e.getX() / cellWidth;
      int row = e.getY() / cellHeight;

      //check if the click is within bounds
      if (row >= 0 && row < board.length && col >= 0 && col < board[0].length) {

        //if clicked on the same cell, deselect
        if (row == selectedRow && col == selectedCol) {
          selectedRow = -1;
          selectedCol = -1;
        } else {
          // Select the new cell
          selectedRow = row;
          selectedCol = col;
//        ap.append("Clicked cell at (" + row + ", " + col + ")\n");
        }
        repaint();

        // Notify features of the cell selection
        if (features != null) {
          features.selectCell(selectedRow, selectedCol);
        }
      }
    }
  }


  /**
   * Draws a single cell in the board, including card values if it’s a Card instance.
   *
   * @param g2         the Graphics2D object
   * @param piece      the BoardPiece at this cell
   * @param x          the x-coordinate of the cell's top-left corner
   * @param y          the y-coordinate of the cell's top-left corner
   * @param cellWidth  The width of the individual cell.
   * @param cellHeight The height of the individual cell.
   */
  private void drawCell(Graphics2D g2, Cell piece, int x, int y, int cellWidth, int cellHeight) {
    //hole cell
    if (piece.isHole()) {
      g2.setColor(Color.LIGHT_GRAY);  //hole
      // card cell with a specific owner color
    } else if (piece.isCard()) {
      g2.setColor(convertToAwtColor(piece.getOwnerColor())); // use owner's color for card cells
      //empty cell
    } else if (piece instanceof Cell) {
      g2.setColor(Color.YELLOW);
    }

    g2.fillRect(x, y, cellWidth, cellHeight);

    //draw card if present
    if (piece.isCard()) {
      piece.getCard().render(g2, x, y, cellWidth, cellHeight); // Use render method of the card
    }

    //draw the cell border
    g2.setColor(Color.BLACK);
    g2.drawRect(x, y, cellWidth, cellHeight);
  }

  /**
   * Converts the model color to a corresponding AWT color.
   *
   * @param modelColor The color in the game model.
   * @return The equivalent java.awt.Color.
   */
  private java.awt.Color convertToAwtColor(model.Color modelColor) {
    if (modelColor == model.Color.RED) {
      return java.awt.Color.PINK;
    } else if (modelColor == model.Color.BLUE) {
      return new Color(173, 216, 240);
    }
    //default or add other colors as needed
    return java.awt.Color.WHITE;
  }

  /**
   * Returns the preferred size of the panel based on its current size.
   *
   * @return A Dimension object representing the preferred size of the panel.
   */
  @Override
  public Dimension getPreferredSize() {
    //set preferred size based on the board and available space dynamically
    return new Dimension(getWidth(), getHeight());
  }

  /**
   * Returns the currently selected row and column as a list.
   *
   * @return A List containing the row and column of the selected cell.
   */
  public List<Integer> getSelectedRowCol() {
    List<Integer> arr = new ArrayList<Integer>();
    arr.add(selectedRow);
    arr.add(selectedCol);
    return arr;
  }

  /**
   * Deselects the currently selected cell.
   */
  public void deselectRowCol() {
    selectedRow = -1;
    selectedCol = -1;
  }

  public void updateBoard(Cell[][] newBoard) {
    this.board = newBoard;
    this.selectedRow = -1; // Reset selection
    this.selectedCol = -1;
    this.repaint();
  }
}





