
import java.util.List;
import java.util.Scanner;

import javax.swing.SwingUtilities;

import controller.AIListener;
import controller.ControllerTTB;
import controller.HumanPlayer;
import controller.ModelListener;
import controller.PlayerController;
import controller.PlayerObserver;
import model.Color;
import model.MutableTTB;
import model.TTB;
import view.GameFrame;

/**
 * Entry point for the ThreeTrios game application, setting up and launching the game environment.
 *
 * <p>
 * <ul>
 *   <li>Initializes the board and cards.</li>
 *   <li>Sets up game controller and UI, w actions to handle card placements and manage turns.</li>
 * </ul>
 **/
public final class ThreeTrios {
  /**
   * main to run and initialize the game.
   */
  public static void main(String[] args) {

    //initialize the game with the desired board size
    int rows = 5;
    int cols = 7;

    //define the grid layout with holes and empty cells
    // 'C' represents an open spot, 'X' represents a hole
    char[][] readGrid = {
            {'C', 'C', 'X', 'X', 'X', 'X', 'C'},
            {'C', 'X', 'C', 'X', 'X', 'X', 'C'},
            {'C', 'X', 'X', 'C', 'X', 'X', 'C'},
            {'C', 'X', 'X', 'X', 'C', 'X', 'C'},
            {'C', 'X', 'X', 'X', 'X', 'C', 'C'},
    };

    char[][] testGrid = {
            {'C', 'C', 'C',},
            {'C', 'C', 'C',},
            {'C', 'C', 'C',}
    };


    //define card descriptions to populate the deck
    List<String> cardDescriptions = List.of(
            "Card1", "2", "5", "3", "4",
            "Card2", "10", "2", "3", "10",
            "Card3", "4", "4", "4", "4",
            "Card4", "1", "5", "2", "4",
            "Card5", "5", "2", "5", "10",
            "Card6", "6", "4", "7", "4",
            "Card7", "3", "5", "6", "4",
            "Card8", "4", "2", "9", "10",
            "Card9", "9", "4", "9", "4",
            "Card10", "1", "2", "5", "10",
            "Card11", "6", "4", "3", "4",
            "Card12", "5", "5", "1", "4",
            "Card13", "4", "2", "3", "10",
            "Card14", "8", "4", "8", "4",
            "Card15", "1", "1", "1", "1",
            "Card16", "2", "5", "7", "9"
    );

    //actually implement two views and have it in final state:
    MutableTTB model = new TTB(rows, cols);
    // Start the game to initialize players and board
    model.startGame(rows, cols, readGrid, cardDescriptions, true);
    SwingUtilities.invokeLater(() -> {
      GameFrame redView = new GameFrame(
              model.getPlayerRed().getHand(),
              model.getPlayerBlue().getHand(),
              model.getBoard(),
              model,
              "Player Red"
      );


      GameFrame blueView = new GameFrame(
              model.getPlayerRed().getHand(),
              model.getPlayerBlue().getHand(),
              model.getBoard(),
              model,
              "Player Blue"
      );

      Scanner scan = new Scanner(System.in);
      ModelListener redController;
      ModelListener blueController;
      PlayerObserver<Color> redPlayer = new HumanPlayer(redView, Color.RED);
      PlayerObserver<Color> bluePlayer = new HumanPlayer(blueView, Color.BLUE);


      while (true) {
        System.out.print("Should Red player be \"AI\" or \"Human\": ");
        String redP = scan.nextLine();
        if (redP.equalsIgnoreCase("AI")) {
          System.out.print("Enter strategy for AI (strategy_1 (minimax), strategy_2(greedy), " +
                  "or strategy_3 (min-value-of-edge)): ");
          String redStrategy = scan.nextLine();
          redController = new AIListener(redPlayer, model, redView, redStrategy);
          break;
        } else if (redP.equalsIgnoreCase("Human")) {
          redController = new PlayerController(redPlayer, model, redView);
          break;
        }
      }

      while (true) {
        System.out.print("Should Blue player be \"AI\" or \"Human\": ");
        String redP = scan.nextLine();
        if (redP.equalsIgnoreCase("AI")) {
          System.out.print("Enter strategy for AI (strategy_1 (minimax), strategy_2(greedy), " +
                  "or strategy_3 (min-value-of-edge)): ");
          String blueStrategy = scan.nextLine();
          blueController = new AIListener(bluePlayer, model, blueView, blueStrategy);
          break;
        } else if (redP.equalsIgnoreCase("Human")) {
          blueController = new PlayerController(bluePlayer, model, blueView);
          break;
        }
      }

      ControllerTTB controller = new ControllerTTB(model, redController, blueController);
      controller.startGame(rows, cols, readGrid, cardDescriptions, true);

    });

  }
}






